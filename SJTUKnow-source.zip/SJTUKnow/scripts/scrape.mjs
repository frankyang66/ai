import path from "node:path";
import fs from "node:fs/promises";
import crypto from "node:crypto";
import * as cheerio from "cheerio";
import sharp from "sharp";

import {
  BROWSER_USER_AGENT,
  fetchBinary,
  fetchJson,
  fetchPage,
} from "./lib/http.mjs";
import { SOURCES, WECHAT_CURATION } from "./sources.mjs";
import {
  cleanText,
  cleanTitle,
  classifyCategory,
  detectRegistration,
  intentOf,
  makeId,
  parseDate,
  toAbsoluteUrl,
} from "./lib/util.mjs";

const ROOT = path.resolve(import.meta.dirname, "..");
const DATA_DIR = path.join(ROOT, "src", "data");
const NOTICES_PATH = path.join(DATA_DIR, "notices.json");
const SOURCES_PATH = path.join(DATA_DIR, "sources.json");
const META_PATH = path.join(DATA_DIR, "meta.json");
const WECHAT_CACHE_PATH = path.join(DATA_DIR, "wechat-cache.json");
const WECHAT_QUEUE_PATH = path.join(DATA_DIR, "wechat-queue.json");
const CUSTOM_SOURCES_PATH = path.join(DATA_DIR, "custom-sources.json");
const COVER_DIR = path.join(ROOT, "public", "media", "covers");

const CONCURRENCY = 4;
const DEFAULT_MAX_ITEMS = 30;
const SKIP_TITLE_RE =
  /^(更多|查看更多|more|首页|上一页|下一页|尾页|返回|登录|注册|English|EN)$/i;
const BAD_COVER_RE =
  /logo|icon|placeholder|temp|qrcode|qr_code|default|avatar|banner_bg/i;
const ARTICLE_COVER_LIMIT = 8;
const SKIP_ARTICLE_COVERS = process.env.SKIP_ARTICLE_COVERS === "1";
const VISIBLE_CATEGORY_IDS = new Set([
  "lectures",
  "careers",
  "arts",
  "services",
]);
const ACTIVITY_CATEGORY_IDS = new Set([
  "lectures",
  "arts",
  "clubs",
  "careers",
  "exchange",
  "growth",
]);
let previousCovers = new Map();

function resolveCover(src, baseUrl) {
  const value = String(src ?? "").trim();
  if (!value || value === "/" || value.startsWith("data:")) return "";
  if (BAD_COVER_RE.test(value)) return "";
  let absolute = toAbsoluteUrl(value, baseUrl);
  if (!absolute) return "";
  if (
    absolute.startsWith("http://") &&
    /(\.sjtu\.edu\.cn|aliyuncs\.com)/i.test(absolute)
  ) {
    absolute = absolute.replace(/^http:\/\//, "https://");
  }
  return absolute;
}

function listCover($, $item, source, finalUrl) {
  const cover = source.cover;
  if (!cover) return "";
  if (cover.method === "list_img") {
    const $img = $item.find(cover.selector).first();
    if ($img.length === 0) return "";
    return resolveCover($img.attr("src") || $img.attr("data-src"), finalUrl);
  }
  if (cover.method === "auto") {
    const $img = $item.find("img").first();
    if ($img.length === 0) return "";
    return resolveCover($img.attr("src") || $img.attr("data-src"), finalUrl);
  }
  if (cover.method === "list_style") {
    const $node = $item.find(cover.selector).first();
    const style = $node.attr("style") || "";
    const match = /url\((['"]?)([^'")]+)\1\)/i.exec(style);
    return match ? resolveCover(match[2], finalUrl) : "";
  }
  return "";
}

async function articleCover(url, source) {
  const cover = source.cover;
  if (!cover || !cover.method.startsWith("article")) return "";
  try {
    const { html, finalUrl } = await fetchPage(url);
    const $ = cheerio.load(html);
    let src = "";
    if (cover.method === "article_og") {
      src =
        $('meta[property="og:image"]').attr("content") ||
        $('meta[name="twitter:image"]').attr("content") ||
        "";
    } else if (cover.method === "auto") {
      src =
        $('meta[property="og:image"]').attr("content") ||
        $('meta[name="twitter:image"]').attr("content") ||
        "";
      if (!src) {
        const selectors = [
          "#js_content img",
          ".rich_media_content img",
          "article img",
          ".article-content img",
          ".article_content img",
          ".content img",
          "main img",
        ];
        for (const selector of selectors) {
          const $img = $(selector).first();
          if ($img.length === 0) continue;
          const width = Number($img.attr("width"));
          const height = Number($img.attr("height"));
          if ((width && width < 200) || (height && height < 120)) continue;
          const candidate = $img.attr("src") || $img.attr("data-src");
          if (candidate && !BAD_COVER_RE.test(candidate)) {
            src = candidate;
            break;
          }
        }
      }
    } else {
      const $img = $(cover.selector).first();
      src = $img.attr("src") || $img.attr("data-src") || "";
      const width = Number($img.attr("width"));
      const height = Number($img.attr("height"));
      if ((width && width < 200) || (height && height < 120)) return "";
    }
    return resolveCover(src, finalUrl);
  } catch {
    return "";
  }
}

function linkTitle($, $link) {
  const titled = $link.attr("title");
  if (titled) return cleanText(titled);
  const heading = cleanText($link.find("h1, h2, h3, h4, h5, h6").first().text());
  if (heading.length >= 4) return heading;
  return cleanText($link.text());
}

function extractConfiguredItems($, source, finalUrl) {
  const { item, link = "a", date, summary } = source.selectors;
  const results = [];

  $(item).each((_, element) => {
    const $item = $(element);
    const $link = $item.find(link).first();
    if ($link.length === 0) return;

    const href = toAbsoluteUrl(
      $link.attr("href") ?? $link.attr("data-href"),
      finalUrl,
    );
    const rawTitle = (linkTitle($, $link) || cleanText($item.text())).slice(
      0,
      200,
    );
    const title = cleanTitle(rawTitle);

    if (!href || title.length < 4 || SKIP_TITLE_RE.test(title)) return;
    if (!/^https?:/i.test(href)) return;

    const dateText = date
      ? cleanText($item.find(date).first().text())
      : cleanText($item.text());
    const publishedAt = parseDate(dateText) ?? parseDate(rawTitle);
    const eventStart = source.event_listing
      ? parseDate(rawTitle) ?? parseDate(dateText)
      : null;

    const summaryText = summary
      ? cleanText($item.find(summary).first().text()).slice(0, 220)
      : "";
    const coverImage = listCover($, $item, source, finalUrl);

    results.push({
      title,
      url: href,
      publishedAt,
      eventStart,
      summary: summaryText,
      coverImage,
    });
  });

  return results;
}

function extractAutoItems($, source, finalUrl) {
  const candidates = [
    $("main, #content, .content, .list, .news, .notice, article").first(),
    $.root(),
  ];

  for (let index = 0; index < candidates.length; index += 1) {
    const container = candidates[index];
    const isLast = index === candidates.length - 1;
    if (!container || container.length === 0) continue;
    const results = [];
    const seen = new Set();

    container.find("a").each((_, element) => {
      const $link = $(element);
      const href = toAbsoluteUrl($link.attr("href"), finalUrl);
      const rawTitle = linkTitle($, $link).slice(0, 200);
      const title = cleanTitle(rawTitle);

      if (!href || title.length < 4 || SKIP_TITLE_RE.test(title)) return;
      if (!/^https?:/i.test(href)) return;
      if (href === finalUrl) return;
      if (seen.has(href)) return;

      const $context = $link.closest("li, tr, p, div");
      const contextText = cleanText($context.text()).slice(0, 400);
      const publishedAt = parseDate(contextText) ?? parseDate(rawTitle);
      const eventStart = source.event_listing
        ? parseDate(rawTitle) ?? parseDate(contextText)
        : null;

      seen.add(href);
      results.push({
        title,
        url: href,
        publishedAt,
        eventStart,
        summary: "",
        coverImage: listCover($, $context, source, finalUrl),
      });
    });

    const dated = results.filter((item) => item.publishedAt);
    if (dated.length >= 3) return results;
    if (isLast) return results;
  }

  return [];
}

async function scrapeQuantEntry(source) {
  const data = await fetchJson("https://quantentry.com/api/catalog");
  const jobs = Array.isArray(data.jobs) ? data.jobs : [];
  const fetchedAt = new Date().toISOString();

  const sorted = jobs
    .filter((job) => job?.apply_url && job?.title)
    .sort((a, b) =>
      String(b.observed_date ?? "").localeCompare(String(a.observed_date ?? "")),
    )
    .slice(0, source.max_items ?? 80);

  const notices = sorted.map((job) => {
    const firm = job.firm_name_cn || job.firm_name_en || "";
    const title = firm ? `${firm}｜${job.title}` : job.title;
    const zh = job.jd_summary?.zh;
    const summaryParts = [zh?.overview];
    if (zh?.requirements?.[0]) summaryParts.push(`要求：${zh.requirements[0]}`);
    const summary = summaryParts.filter(Boolean).join(" ").slice(0, 220);
    const location =
      (Array.isArray(job.locations) && job.locations.length > 0
        ? job.locations.join(" / ")
        : job.location) || undefined;
    const publishedAt = job.observed_date
      ? `${job.observed_date}T09:00:00+08:00`
      : fetchedAt;

    return {
      id: makeId(`quantentry:${job.job_id}`),
      title,
      source_id: source.id,
      source_name: source.name,
      category: "careers",
      intent: "activity",
      published_at: publishedAt,
      url: job.apply_url,
      summary: summary || undefined,
      location,
      requires_registration: undefined,
    };
  });

  return { notices, extractedCount: jobs.length };
}

async function loadCustomSources() {
  const list = await readJson(CUSTOM_SOURCES_PATH, []);
  if (!Array.isArray(list)) return [];
  return list
    .filter(
      (item) =>
        item &&
        typeof item.id === "string" &&
        typeof item.name === "string" &&
        typeof item.url === "string" &&
        /^https?:\/\//i.test(item.url),
    )
    .slice(0, 100)
    .map((item) => {
      const haystack = `${item.name} ${item.url}`.toLowerCase();
      const defaultCategory = /(招聘|job|career|实习|recruit)/i.test(haystack)
        ? "careers"
        : /(讲座|lecture|seminar|报告)/i.test(haystack)
          ? "lectures"
          : /(文体|art|演出|体育|展览)/i.test(haystack)
            ? "arts"
            : "services";
      return {
      id: item.id,
      name: item.name.slice(0, 100),
      unit: "自定义来源",
      type: item.type === "wechat" ? "wechat" : "official_site",
      homepage: item.url,
      listing_url: item.url,
      content_types: ["自定义"],
      categories: [defaultCategory],
      default_category: defaultCategory,
      cadence: "手动添加",
      priority: "medium",
      custom: true,
      allow_no_date: false,
      max_items: 20,
      cover: { method: "auto" },
      wechat_article: /^https?:\/\/mp\.weixin\.qq\.com\/s[/?]/i.test(item.url)
        ? true
        : undefined,
      };
    });
}

async function scrapeWechatArticle(source) {
  const info = await fetchWechatMeta(source.listing_url);
  if (!info || info.error) {
    return { notices: [], extractedCount: 0 };
  }
  const title = cleanTitle(info.title || source.name).slice(0, 200);
  const category = classifyCategory(title, source.default_category);
  const publishedAt = info.publishedAt || new Date().toISOString();
  const coverImage = info.cover ? await cacheCover(info.cover) : undefined;

  return {
    notices: [
      {
        id: makeId(`wechat:${source.listing_url}`),
        title,
        source_id: source.id,
        source_name: source.name,
        category,
        intent: intentOf(category),
        published_at: publishedAt,
        url: source.listing_url,
        cover_image: coverImage,
        requires_registration: detectRegistration(title) || undefined,
      },
    ],
    extractedCount: 1,
  };
}

async function scrapeSingleArticle(source) {
  try {
    const { html } = await fetchPage(source.listing_url, {
      userAgent: BROWSER_USER_AGENT,
    });
    const $ = cheerio.load(html);
    const rawTitle =
      $('meta[property="og:title"]').attr("content") ||
      $('meta[name="twitter:title"]').attr("content") ||
      $("h1").first().text() ||
      $("title").first().text();
    const title = cleanTitle(rawTitle || source.name).slice(0, 200);
    if (!title) return { notices: [], extractedCount: 0 };
    let cover = $('meta[property="og:image"]').attr("content") || "";
    if (!cover) {
      for (const selector of ["#js_content img", "article img", ".content img", "main img"]) {
        const $img = $(selector).first();
        const candidate = $img.attr("src") || $img.attr("data-src");
        if (candidate && !BAD_COVER_RE.test(candidate)) {
          cover = candidate;
          break;
        }
      }
    }
    const category = classifyCategory(title, source.default_category);
    return {
      notices: [
        {
          id: makeId(source.listing_url),
          title,
          source_id: source.id,
          source_name: source.name,
          category,
          intent: intentOf(category),
          published_at: new Date().toISOString(),
          url: source.listing_url,
          cover_image: cover ? await cacheCover(cover) : undefined,
          requires_registration: detectRegistration(title) || undefined,
        },
      ],
      extractedCount: 1,
    };
  } catch {
    return { notices: [], extractedCount: 0 };
  }
}

async function scrapeSource(source) {
  if (source.api === "quantentry") return scrapeQuantEntry(source);
  if (source.wechat_article) return scrapeWechatArticle(source);

  const { html, finalUrl } = await fetchPage(source.listing_url);
  const $ = cheerio.load(html, { decodeEntities: true });

  const extracted = source.selectors
    ? extractConfiguredItems($, source, finalUrl)
    : extractAutoItems($, source, finalUrl);

  if (source.custom && extracted.length === 0) {
    return scrapeSingleArticle(source);
  }

  const seen = new Set();
  const fetchedAt = new Date().toISOString();
  const fetchedMs = Date.parse(fetchedAt);
  const limit = source.max_items ?? DEFAULT_MAX_ITEMS;
  const notices = [];

  for (const [index, item] of extracted.entries()) {
    if (seen.has(item.url)) continue;
    seen.add(item.url);

    if (!item.publishedAt && !source.allow_no_date) continue;

    // Event-list pages list upcoming sessions rather than publish times:
    // keep list order via collected time, and store the real event date.
    const publishedAt = source.event_listing
      ? new Date(fetchedMs - index * 1000).toISOString()
      : item.publishedAt ?? fetchedAt;
    const eventStart = source.event_listing
      ? item.eventStart ?? item.publishedAt ?? undefined
      : item.eventStart ?? undefined;
    const classified = classifyCategory(item.title, source.default_category);
    const finalCategory =
      source.event_listing && !ACTIVITY_CATEGORY_IDS.has(classified)
        ? source.default_category ?? "lectures"
        : classified;
    const finalIntent = source.event_listing
      ? "activity"
      : intentOf(finalCategory);

    notices.push({
      id: makeId(item.url),
      title: item.title,
      source_id: source.id,
      source_name: source.name,
      category: finalCategory,
      intent: finalIntent,
      published_at: publishedAt,
      event_start: eventStart,
      url: item.url,
      summary: item.summary || undefined,
      cover_image: item.coverImage || previousCovers.get(item.url) || undefined,
      requires_registration: detectRegistration(item.title) || undefined,
    });

    if (notices.length >= limit) break;
  }

  if (
    !SKIP_ARTICLE_COVERS &&
    source.cover &&
    source.cover.method.startsWith("article")
  ) {
    let fetched = 0;
    for (const notice of notices) {
      if (notice.cover_image) continue;
      if (fetched >= ARTICLE_COVER_LIMIT) break;
      fetched += 1;
      const coverImage = await articleCover(notice.url, source);
      if (coverImage) notice.cover_image = coverImage;
    }
  }

  for (const notice of notices) {
    if (notice.cover_image) {
      notice.cover_image = await cacheCover(notice.cover_image);
    }
  }

  return { notices, extractedCount: extracted.length };
}

function decodeEntities(value) {
  return String(value ?? "")
    .replace(/\\x26amp;/g, "&")
    .replace(/\\x26/g, "&")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ");
}

function normalizeName(value) {
  return String(value ?? "")
    .replace(/[\s·|｜:：,，。.()（）\[\]【】「」]/g, "")
    .toLowerCase();
}

async function fetchWechatMeta(url) {
  try {
    const { html } = await fetchPage(url, {
      userAgent: BROWSER_USER_AGENT,
      timeoutMs: 25000,
    });
    const $page = cheerio.load(html);
    const accountMatch =
      /nickname\s*=\s*htmlDecode\("([^"]+)"\)/.exec(html) ||
      /id="js_name"[^>]*>\s*([^<]+)/.exec(html);
    const userNameMatch = /var user_name = "([^"]+)"/.exec(html);
    const ctMatch = /var ct = "(\d+)"/.exec(html);
    const title =
      $page('meta[property="og:title"]').attr("content") ||
      $page('meta[name="twitter:title"]').attr("content") ||
      "";
    const cover = $page('meta[property="og:image"]').attr("content") || "";
    const account = accountMatch ? decodeEntities(accountMatch[1]).trim() : "";
    const userName = userNameMatch ? userNameMatch[1].trim() : "";
    const publishedAt = ctMatch
      ? new Date(Number(ctMatch[1]) * 1000).toISOString()
      : null;
    const related = Array.from(
      new Set(
        Array.from(
          html.matchAll(
            /https?:\/\/mp\.weixin\.qq\.com\/s\?(?:__biz|scene)[^"'\s<>\\]+/g,
          ),
        )
          .map((match) =>
            match[0]
              .replace(/&amp;amp;/g, "&")
              .replace(/&amp;/g, "&")
              .split("#")[0],
          )
          .filter(
            (link) =>
              !link.includes("${") &&
              link.includes("__biz=") &&
              link.includes("mid=") &&
              link.includes("sn="),
          ),
      ),
    ).slice(0, 8);
    if (!title && !cover) return { error: true };
    return { title, cover, account, userName, publishedAt, related };
  } catch {
    return { error: true };
  }
}

async function enrichWechatNotices(notices, dynamicSources) {
  let cache = await readJson(WECHAT_CACHE_PATH, {});
  if (!cache || typeof cache !== "object") cache = {};
  const queueList = await readJson(WECHAT_QUEUE_PATH, []);
  const queue = new Set(Array.isArray(queueList) ? queueList : []);

  const curated = new Map();
  for (const source of SOURCES) {
    if (source.type === "wechat") {
      curated.set(normalizeName(source.name), source);
    }
  }

  const resolveAccount = (accountName, userName, url) => {
    if (!accountName) return null;
    const matched = curated.get(normalizeName(accountName));
    if (matched) return { id: matched.id, name: matched.name };
    const curatedCategories = WECHAT_CURATION.get(normalizeName(accountName));
    if (!curatedCategories) return null;
    const key = userName || accountName;
    const hash = crypto
      .createHash("sha1")
      .update(key)
      .digest("hex")
      .slice(0, 10);
    const id = `wx_dyn_${hash}`;
    if (!dynamicSources.has(id)) {
      dynamicSources.set(id, {
        id,
        name: accountName,
        type: "wechat",
        unit: "微信公众号（自动收录）",
        homepage: url,
        listing_url: url,
        content_types: ["公众号文章"],
        categories: [...curatedCategories],
        cadence: "随公开链接更新",
        priority: "medium",
        notes: "由公开文章页自动识别账号",
      });
    }
    return { id, name: accountName };
  };

  const addRelated = (info) => {
    for (const link of info?.related ?? []) queue.add(link);
  };

  let fetched = 0;
  const limit = Number(process.env.WECHAT_FETCH_LIMIT ?? 60);

  for (const notice of notices) {
    if (!/^https?:\/\/mp\.weixin\.qq\.com\/s[/?]/i.test(notice.url)) {
      continue;
    }
    let info = cache[notice.url];
    if (info?.error && notice.seed) info = undefined;
    if (!info && fetched < limit) {
      fetched += 1;
      info = await fetchWechatMeta(notice.url);
      cache[notice.url] = info;
    }
    if (!info || info.error) continue;
    addRelated(info);

    if (info.title) notice.title = cleanTitle(info.title).slice(0, 200);
    if (info.publishedAt) notice.published_at = info.publishedAt;
    if (info.cover) notice.cover_image = await cacheCover(info.cover);
    notice.wechat = true;
    notice.wechat_account = info.account || "";
    notice.wechat_user_name = info.userName || "";

    // Custom sources keep their own identity so users see the source they added.
    if (notice.source_id.startsWith("custom_")) continue;

    const account = resolveAccount(
      info.account || "",
      info.userName || "",
      notice.url,
      notice.category,
    );
    if (account) {
      notice.source_id = account.id;
      notice.source_name = account.name;
    }
  }

  const extras = [];
  const existingUrls = new Set(notices.map((notice) => notice.url));
  const queueLimit = Number(process.env.WECHAT_QUEUE_LIMIT ?? 20);
  let queueFetched = 0;

  for (const url of queue) {
    if (queueFetched >= queueLimit) break;
    if (existingUrls.has(url)) continue;
    let info = cache[url];
    if (!info) {
      queueFetched += 1;
      info = await fetchWechatMeta(url);
      cache[url] = info;
    }
    if (!info || info.error || !info.title) continue;
    addRelated(info);

    const title = cleanTitle(info.title).slice(0, 200);
    if (!title) continue;
    const category = classifyCategory(title, "campus");
    const account = resolveAccount(
      info.account || "",
      info.userName || "",
      url,
    );
    if (!account) continue;
    const coverImage = info.cover ? await cacheCover(info.cover) : undefined;

    extras.push({
      id: makeId(`wechat:${url}`),
      title,
      source_id: account?.id ?? "wechat_auto",
      source_name: account?.name ?? "微信公众号",
      category,
      intent: intentOf(category),
      published_at: info.publishedAt || new Date().toISOString(),
      url,
      cover_image: coverImage,
      wechat: true,
      wechat_account: info.account || "",
      wechat_user_name: info.userName || "",
      requires_registration: detectRegistration(title) || undefined,
    });
    existingUrls.add(url);
  }

  await fs.writeFile(
    WECHAT_CACHE_PATH,
    `${JSON.stringify(cache, null, 2)}\n`,
  );
  await fs.writeFile(
    WECHAT_QUEUE_PATH,
    `${JSON.stringify(Array.from(queue).slice(0, 800), null, 2)}\n`,
  );
  return extras;
}

async function cacheCover(url) {
  if (!/^https?:\/\//i.test(url)) return url;
  const hash = crypto.createHash("sha1").update(url).digest("hex").slice(0, 20);
  const filename = `${hash}.webp`;
  const filePath = path.join(COVER_DIR, filename);
  const publicPath = `/media/covers/${filename}`;

  try {
    await fs.access(filePath);
    return publicPath;
  } catch {
    // Not cached yet.
  }

  try {
    const { buffer } = await fetchBinary(url);
    const output = await sharp(buffer)
      .rotate()
      .resize({ width: 720, withoutEnlargement: true, fit: "inside" })
      .webp({ quality: 76 })
      .toBuffer();
    await fs.mkdir(COVER_DIR, { recursive: true });
    await fs.writeFile(filePath, output);
    return publicPath;
  } catch {
    return url;
  }
}

async function readJson(filePath, fallback) {
  try {
    const raw = await fs.readFile(filePath, "utf8");
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function publicSourceConfig(source) {
  return {
    id: source.id,
    name: source.name,
    type: source.type,
    unit: source.unit,
    homepage: source.homepage,
    listing_url: source.listing_url,
    content_types: source.content_types ?? [],
    categories: source.categories ?? [],
    cadence: source.cadence,
    wechat_id: source.wechat_id,
    priority: source.priority,
    notes: source.notes,
  };
}

async function main() {
  const existingNotices = await readJson(NOTICES_PATH, []);
  previousCovers = new Map(
    existingNotices
      .filter((notice) => notice.cover_image)
      .map((notice) => [notice.url, notice.cover_image]),
  );

  const customSources = await loadCustomSources();
  const allSources = [...SOURCES, ...customSources];

  const only = new Set(process.argv.slice(2));
  const scrapeTargets = allSources.filter(
    (source) =>
      source.listing_url &&
      (source.type === "official_site" ||
        source.wechat_article ||
        source.custom) &&
      (only.size === 0 || only.has(source.id)),
  );

  if (scrapeTargets.length === 0) {
    console.log("没有可抓取的信息源，请先完善 scripts/sources.mjs。");
    return;
  }

  console.log(`准备抓取 ${scrapeTargets.length} 个信息源…`);

  const results = [];
  let cursor = 0;

  async function worker() {
    while (cursor < scrapeTargets.length) {
      const index = cursor;
      cursor += 1;
      const source = scrapeTargets[index];

      try {
        const result = await scrapeSource(source);
        results.push({ source, ...result });
        console.log(
          `  ✓ ${source.name}：${result.notices.length} 条（列表候选 ${result.extractedCount}）`,
        );
      } catch (error) {
        results.push({ source, notices: [], error });
        console.warn(`  ✗ ${source.name}：${error.message}`);
      }
    }
  }

  await Promise.all(
    Array.from({ length: Math.min(CONCURRENCY, scrapeTargets.length) }, worker),
  );

  const existing = await readJson(NOTICES_PATH, []);
  const byId = new Map(existing.map((notice) => [notice.id, notice]));
  let added = 0;

  for (const result of results) {
    if (result.error || !result.source.custom) continue;
    for (const [id, notice] of byId) {
      if (notice.source_id === result.source.id) byId.delete(id);
    }
  }

  for (const result of results) {
    for (const notice of result.notices) {
      if (!byId.has(notice.id)) added += 1;
      byId.set(notice.id, notice);
    }
  }

  // Seed a few public articles for WeChat accounts that have no list page.
  const seedNow = new Date().toISOString();
  const seedIds = new Set();
  for (const source of SOURCES) {
    if (source.type !== "wechat" || !Array.isArray(source.seed_articles)) {
      continue;
    }
    for (const url of source.seed_articles) {
      if (!/^https?:\/\/mp\.weixin\.qq\.com\//i.test(url)) continue;
      const id = makeId(`wechat:${url}`);
      seedIds.add(id);
      const existingSeed = byId.get(id);
      if (existingSeed) {
        existingSeed.seed = true;
        continue;
      }
      const category = source.default_category ?? "campus";
      byId.set(id, {
        id,
        title: source.name,
        source_id: source.id,
        source_name: source.name,
        category,
        intent: intentOf(category),
        published_at: seedNow,
        url,
        seed: true,
        requires_registration: false,
      });
    }
  }

  const dynamicSources = new Map();
  const allForEnrichment = Array.from(byId.values());
  const wechatExtras = await enrichWechatNotices(
    [
      ...allForEnrichment.filter((notice) => seedIds.has(notice.id)),
      ...allForEnrichment.filter((notice) => !seedIds.has(notice.id)),
    ],
    dynamicSources,
  );
  for (const notice of wechatExtras) byId.set(notice.id, notice);

  // Keep only WeChat accounts the curators retained.
  for (const [id, notice] of byId) {
    if (notice.source_id?.startsWith("custom_")) continue;
    const isWechat =
      notice.wechat ||
      notice.source_id?.startsWith("wx_") ||
      notice.source_id === "wechat_auto";
    if (!isWechat) continue;
    const name = normalizeName(notice.source_name || notice.wechat_account || "");
    if (WECHAT_CURATION.has(name)) continue;
    byId.delete(id);
  }

  const now = new Date();
  const chinaNow = new Date(now.getTime() + 8 * 60 * 60 * 1000);
  const todayStart =
    Date.UTC(
      chinaNow.getUTCFullYear(),
      chinaNow.getUTCMonth(),
      chinaNow.getUTCDate(),
    ) -
    8 * 60 * 60 * 1000;
  const activityCutoff = now.getTime() - 30 * 24 * 60 * 60 * 1000;
  const noticeCutoff = now.getTime() - 180 * 24 * 60 * 60 * 1000;
  const eventTimeCutoff = now.getTime() - 2 * 60 * 60 * 1000;

  const customIds = new Set(customSources.map((source) => source.id));
  const notices = Array.from(byId.values())
    .filter(
      (notice) =>
        !notice.source_id.startsWith("custom_") ||
        customIds.has(notice.source_id),
    )
    .filter((notice) => VISIBLE_CATEGORY_IDS.has(notice.category))
    .filter((notice) => {
      const published = new Date(notice.published_at).getTime();
      if (notice.intent === "activity") {
        if (notice.event_start) {
          const eventTime = new Date(notice.event_start).getTime();
          if (!Number.isNaN(eventTime)) {
            const hasClock = /T(?!00:00)/.test(notice.event_start);
            // Date-only events stay for the whole day; timed events get 2h grace.
            return hasClock ? eventTime >= eventTimeCutoff : eventTime >= todayStart;
          }
        }
        return Number.isNaN(published) || published >= activityCutoff;
      }
      return Number.isNaN(published) || published >= noticeCutoff;
    })
    .sort(
      (a, b) =>
        new Date(b.published_at).getTime() - new Date(a.published_at).getTime(),
    );

  const filterCategories = (categories) =>
    (categories ?? []).filter((category) =>
      VISIBLE_CATEGORY_IDS.has(category),
    );

  const publicSources = [
    ...allSources
      .filter((source) => {
        if (source.custom) return true;
        if (source.type === "wechat") return true;
        return filterCategories(source.categories).length > 0;
      })
      .map((source) =>
        publicSourceConfig({
          ...source,
          categories: filterCategories(source.categories),
        }),
      ),
    ...Array.from(dynamicSources.values()).map((source) => ({
      ...source,
      categories: filterCategories(source.categories),
    })),
  ];
  const meta = {
    generated_at: now.toISOString(),
    notice_count: notices.length,
    source_count: publicSources.length,
  };

  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.writeFile(NOTICES_PATH, `${JSON.stringify(notices, null, 2)}\n`);
  await fs.writeFile(
    SOURCES_PATH,
    `${JSON.stringify(publicSources, null, 2)}\n`,
  );
  await fs.writeFile(META_PATH, `${JSON.stringify(meta, null, 2)}\n`);

  const failed = results.filter((result) => result.error).length;
  console.log(
    `\n完成：新增 ${added} 条，累计 ${notices.length} 条；信息源 ${publicSources.length} 个${
      failed > 0 ? `，失败 ${failed} 个` : ""
    }。`,
  );
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
