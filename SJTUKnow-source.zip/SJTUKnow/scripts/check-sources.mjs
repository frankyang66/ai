import * as cheerio from "cheerio";

import { fetchPage } from "./lib/http.mjs";
import { SOURCES } from "./sources.mjs";

const targets = SOURCES.filter(
  (source) => source.type === "official_site" && source.listing_url,
);

if (targets.length === 0) {
  console.log("scripts/sources.mjs 中还没有配置官网列表页。");
  process.exit(0);
}

let failed = 0;

for (const source of targets) {
  try {
    const { html, finalUrl } = await fetchPage(source.listing_url);
    const $ = cheerio.load(html);
    const title = $("title").first().text().trim();
    const links = $("a").length;
    console.log(
      `✓ ${source.id.padEnd(28)} ${String(links).padStart(4)} 链接  ${title.slice(0, 48)}`,
    );
    if (finalUrl !== source.listing_url) {
      console.log(`    ↳ 重定向至 ${finalUrl}`);
    }
  } catch (error) {
    failed += 1;
    console.warn(`✗ ${source.id.padEnd(28)} ${error.message}`);
  }
}

console.log(
  `\n检查完成：${targets.length - failed}/${targets.length} 个信息源可访问。`,
);
if (failed > 0) process.exitCode = 1;
