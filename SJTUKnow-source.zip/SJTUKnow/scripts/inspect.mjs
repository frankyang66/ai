import * as cheerio from "cheerio";
import { fetchPage } from "./lib/http.mjs";
import { cleanText, parseDate } from "./lib/util.mjs";

const url = process.argv[2];
if (!url) {
  console.error("用法：node scripts/inspect.mjs <列表页 URL>");
  process.exit(1);
}

const { html, finalUrl } = await fetchPage(url);
const $ = cheerio.load(html);

console.log(`URL: ${finalUrl}`);
console.log(`标题: ${cleanText($("title").text())}`);
console.log(`链接总数: ${$("a").length}\n`);

const candidates = [];

$("ul, ol, table, div").each((_, element) => {
  const $el = $(element);
  const anchors = $el.find("a").filter((_, anchor) => {
    const $anchor = $(anchor);
    return cleanText($anchor.attr("title") || $anchor.text()).length >= 8;
  });

  if (anchors.length < 3) return;

  const withDates = anchors.filter((_, anchor) => {
    const $anchor = $(anchor);
    const context = cleanText($anchor.closest("li, tr, p, div").text());
    return Boolean(parseDate(context)) || Boolean(parseDate(cleanText($anchor.text())));
  });

  if (withDates.length < 3) return;

  const className = $el.attr("class") ?? "";
  const id = $el.attr("id") ?? "";
  const selector = `${element.tagName.toLowerCase()}${id ? `#${id}` : ""}${
    className
      ? `.${className.trim().split(/\s+/).slice(0, 2).join(".")}`
      : ""
  }`;

  candidates.push({
    selector,
    anchors: anchors.length,
    withDates: withDates.length,
    sample: anchors
      .slice(0, 3)
      .map((_, anchor) =>
        cleanText($(anchor).attr("title") || $(anchor).text()).slice(0, 48),
      )
      .get(),
  });
});

candidates.sort((a, b) => b.withDates - a.withDates);

for (const candidate of candidates.slice(0, 6)) {
  console.log(`选择器: ${candidate.selector}`);
  console.log(
    `  链接 ${candidate.anchors} 个，其中 ${candidate.withDates} 个可解析日期`,
  );
  for (const title of candidate.sample) console.log(`  · ${title}`);
  console.log();
}

if (candidates.length === 0) {
  console.log("未找到明显的列表容器，请人工检查页面结构。");
}
