export function SourceStatusBadge({
  source,
}: {
  source: { type: "official_site" | "wechat"; count: number };
}) {
  if (source.type !== "wechat" || source.count > 0) return null;

  return (
    <span
      title="无法自动抓取：公众号文章需要微信授权"
      aria-label="无法自动抓取"
      className="inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full border border-border bg-muted font-mono text-[9px] font-semibold lowercase leading-none text-muted-foreground"
    >
      d
    </span>
  );
}
