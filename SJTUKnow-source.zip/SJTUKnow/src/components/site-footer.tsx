import { getStats } from "@/lib/data";
import { formatStamp } from "@/lib/format";

export function SiteFooter() {
  const stats = getStats();

  return (
    <footer className="mt-6 border-t border-border bg-background">
      <div className="mx-auto flex max-w-[1480px] flex-wrap items-center justify-between gap-2 px-7 py-5 text-xs text-muted-foreground">
        <p>最近更新{formatStamp(stats.generatedAt)}</p>
        <p>项目网站：SJTU Know</p>
      </div>
    </footer>
  );
}
