import Link from "next/link";

export function EmptyState({
  title = "还没有收录内容",
  description = "信息源正在接入中。抓取管线运行后，这里会按分类显示最新的活动与通知。",
}: {
  title?: string;
  description?: string;
}) {
  return (
    <div className="mt-4 rounded-2xl border border-border bg-card px-6 py-16 text-center">
      <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl border border-border bg-muted font-serif text-xl text-muted-foreground">
        知
      </div>
      <p className="text-lg font-semibold text-foreground">{title}</p>
      <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">
        {description}
      </p>
      <Link
        href="/sources"
        className="mt-6 inline-flex items-center gap-1.5 rounded-xl border border-border bg-background px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:border-input hover:bg-accent hover:text-primary"
      >
        查看已核验的信息来源
        <span aria-hidden="true">→</span>
      </Link>
    </div>
  );
}
