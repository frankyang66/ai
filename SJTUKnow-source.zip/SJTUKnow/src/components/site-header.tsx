"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import type { Source } from "@/lib/types";
import { FeedbackPanel } from "./feedback-panel";
import { Icon } from "./icons";
import { Modal } from "./modal";
import { SearchBar } from "./search-bar";
import { SourceManagerPanel } from "./source-manager-panel";
import { SourcesPanel } from "./sources-panel";

type HeaderSource = Source & { count: number };
type DialogName = "sources" | "feedback" | "manage" | null;

export function SiteHeader({ sources }: { sources: HeaderSource[] }) {
  const [dialog, setDialog] = useState<DialogName>(null);
  const pathname = usePathname();
  const hideSearch = pathname === "/search";

  return (
    <>
      <header className="masthead">
        <div className="campus-bar">
          <nav className="campus-switch" aria-label="站点导航">
            <Link href="/" className="campus-tab" data-active="true">
              交大知道
              <span className="sub" lang="en">
                SJTU Know
              </span>
            </Link>
          </nav>
        </div>

        <div className="masthead-inner">
          <h1 className="brand-title">
            <Link
              href="/"
              className="wordmark"
              aria-label="「交大知道」 SJTU Know，首页"
            >
              <span className="brand-mark" aria-hidden="true">
                知
              </span>
              <span className="brand-lettering" aria-hidden="true">
                <span className="brand-bracket">「</span>
                交大知道
                <span className="brand-bracket">」</span>
                <span className="brand-en" lang="en">
                  SJTU Know
                </span>
              </span>
            </Link>
          </h1>

          {hideSearch ? null : (
            <div className="masthead-search">
              <SearchBar />
            </div>
          )}

          <div className={`masthead-actions ${hideSearch ? "ml-auto" : ""}`}>
            <Link href="/calendar" className="control">
              <Icon name="calendar" />
              <span>活动日历</span>
            </Link>
            <button
              type="button"
              className="control icon-control"
              title="留言区"
              aria-label="留言区"
              onClick={() => setDialog("feedback")}
            >
              <Icon name="message" />
            </button>
            <button
              type="button"
              className="control icon-control"
              title="信息来源"
              aria-label="信息来源"
              onClick={() => setDialog("sources")}
            >
              <Icon name="database" />
            </button>
            <button
              type="button"
              className="control icon-control"
              title="来源管理"
              aria-label="来源管理"
              onClick={() => setDialog("manage")}
            >
              <Icon name="sliders" />
            </button>
          </div>
        </div>
      </header>

      {dialog === "sources" ? (
        <Modal title="信息来源" wide onClose={() => setDialog(null)}>
          <SourcesPanel sources={sources} />
        </Modal>
      ) : null}

      {dialog === "feedback" ? (
        <Modal title="留言区" onClose={() => setDialog(null)}>
          <FeedbackPanel />
        </Modal>
      ) : null}

      {dialog === "manage" ? (
        <Modal title="来源管理" wide onClose={() => setDialog(null)}>
          <SourceManagerPanel sources={sources} />
        </Modal>
      ) : null}
    </>
  );
}
