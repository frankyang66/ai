import Link from "next/link";

export function NoticePagination({
  current,
  totalPages,
  pageHref,
}: {
  current: number;
  totalPages: number;
  pageHref: (page: number) => string;
}) {
  if (totalPages <= 1) return null;

  const pages = Array.from({ length: totalPages }, (_, index) => index + 1);

  return (
    <nav aria-label="结果分页" className="mt-8 flex flex-wrap items-center justify-center gap-1.5 text-xs">
      {pages.map((page) => (
        <Link
          key={page}
          href={pageHref(page)}
          aria-current={page === current ? "page" : undefined}
          className={`flex h-8 min-w-8 items-center justify-center rounded-xl border px-2.5 font-semibold transition-colors ${
            page === current
              ? "border-primary bg-primary text-white"
              : "border-border bg-card text-muted-foreground hover:border-input hover:text-primary"
          }`}
        >
          {page}
        </Link>
      ))}
    </nav>
  );
}

export const NOTICE_PAGE_SIZE = 10;

export function paginateNotices<T>(notices: T[], pageParam?: string) {
  const parsed = Number.parseInt(pageParam ?? "1", 10);
  const requested = Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
  const totalPages = Math.max(1, Math.ceil(notices.length / NOTICE_PAGE_SIZE));
  const current = Math.min(requested, totalPages);
  const firstIndex = (current - 1) * NOTICE_PAGE_SIZE;
  return {
    current,
    totalPages,
    items: notices.slice(firstIndex, firstIndex + NOTICE_PAGE_SIZE),
  };
}
