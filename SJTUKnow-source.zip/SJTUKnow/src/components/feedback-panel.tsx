"use client";

import { useEffect, useState } from "react";

interface Message {
  id: string;
  nickname: string;
  content: string;
  created_at: string;
  status: string;
  reply?: string | null;
}

function formatMessageTime(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const parts = new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(date);
  const get = (type: string) =>
    parts.find((part) => part.type === type)?.value ?? "00";
  return `${get("year")}/${get("month")}/${get("day")} ${get("hour")}:${get(
    "minute",
  )}`;
}

export function FeedbackPanel() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [nickname, setNickname] = useState("");
  const [content, setContent] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/messages", { cache: "no-store" });
      const data = await response.json();
      setMessages(Array.isArray(data.messages) ? data.messages : []);
    } catch {
      setMessages([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let cancelled = false;
    fetch("/api/messages", { cache: "no-store" })
      .then((response) => response.json())
      .then((data) => {
        if (cancelled) return;
        setMessages(Array.isArray(data.messages) ? data.messages : []);
        setLoading(false);
      })
      .catch(() => {
        if (cancelled) return;
        setMessages([]);
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!content.trim() || submitting) return;
    setSubmitting(true);
    setNotice("");
    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nickname, content }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "提交失败");
      setMessages((current) => [data.message, ...current]);
      setContent("");
      setNotice("留言已提交，谢谢！");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "提交失败");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <p className="text-sm leading-relaxed text-muted-foreground">
        关于项目的问题、建议，或想补充的信息源，都欢迎在这里留言。
      </p>

      <form onSubmit={submit} className="mt-4 space-y-3">
        <label className="block">
          <span className="mb-1.5 block text-xs font-semibold text-foreground">
            昵称
          </span>
          <input
            value={nickname}
            onChange={(event) => setNickname(event.target.value)}
            maxLength={40}
            placeholder="匿名同学"
            className="h-10 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/10"
          />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-semibold text-foreground">
            留言内容
          </span>
          <textarea
            value={content}
            onChange={(event) => setContent(event.target.value.slice(0, 800))}
            rows={4}
            placeholder="补充公众号时，请附名称和一篇推文链接。"
            className="w-full resize-y rounded-xl border border-input bg-background px-3 py-2 text-sm leading-relaxed outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/10"
          />
        </label>
        <input
          type="text"
          name="website"
          tabIndex={-1}
          autoComplete="off"
          className="hidden"
          aria-hidden="true"
        />
        <div className="flex items-center justify-between gap-3">
          <span className="text-xs text-muted-foreground">
            {content.length}/800
          </span>
          <button
            type="submit"
            disabled={submitting || !content.trim()}
            className="rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-accent-foreground disabled:cursor-not-allowed disabled:opacity-50"
          >
            {submitting ? "提交中…" : "提交留言"}
          </button>
        </div>
        {notice ? (
          <p className="text-xs text-muted-foreground">{notice}</p>
        ) : null}
      </form>

      <div className="mt-6 flex items-center gap-2 border-t border-border pt-4">
        <h3 className="text-sm font-bold text-foreground">
          大家的留言
          <span className="ml-1.5 text-xs font-medium text-muted-foreground">
            {messages.length}
          </span>
        </h3>
        <button
          type="button"
          onClick={load}
          className="ml-auto rounded-lg border border-border bg-card px-2.5 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:border-input hover:text-primary"
        >
          刷新
        </button>
      </div>

      {loading ? (
        <p className="py-6 text-center text-xs text-muted-foreground">
          正在加载留言…
        </p>
      ) : messages.length === 0 ? (
        <p className="py-6 text-center text-xs text-muted-foreground">
          还没有留言，欢迎补充信息源。
        </p>
      ) : (
        <ul className="mt-2 divide-y divide-border">
          {messages.map((message) => (
            <li key={message.id} className="py-3">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                <span className="font-semibold text-foreground">
                  {message.nickname}
                </span>
                <time>{formatMessageTime(message.created_at)}</time>
                <span className="rounded-md bg-muted px-1.5 py-0.5">
                  {message.status}
                </span>
              </div>
              <p className="mt-1.5 whitespace-pre-wrap text-sm leading-relaxed text-foreground/85">
                {message.content}
              </p>
              {message.reply ? (
                <p className="mt-2 rounded-lg bg-muted px-3 py-2 text-xs leading-relaxed text-muted-foreground">
                  <span className="font-semibold text-foreground">
                    开发者回复：
                  </span>
                  {message.reply}
                </p>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
