"use client";

import { useMemo, useSyncExternalStore } from "react";
import {
  getOverrides,
  getServerOverrides,
  mergeSources,
  subscribeOverrides,
  type ManagedSource,
} from "@/lib/source-overrides";
import { SourcesAssistant } from "./sources-assistant";

export function SourcesPanel({ sources }: { sources: ManagedSource[] }) {
  const overrides = useSyncExternalStore(
    subscribeOverrides,
    getOverrides,
    getServerOverrides,
  );
  const merged = useMemo(
    () => mergeSources(sources, overrides),
    [sources, overrides],
  );

  return <SourcesAssistant sources={merged} />;
}
