import Link from "next/link";
import { ACTIVITY_CATEGORIES, NOTICE_CATEGORIES } from "@/lib/categories";
import type { Category, CategoryId } from "@/lib/types";
import { CategoryIcon, Icon } from "./icons";

function Cluster({
  title,
  icon,
  categories,
  activeId,
}: {
  title: string;
  icon: "calendar" | "bell";
  categories: Category[];
  activeId?: CategoryId;
}) {
  return (
    <section className="category-cluster">
      <div className="category-cluster-heading">
        <span className="category-cluster-icon">
          <Icon name={icon} />
        </span>
        <strong>{title}</strong>
      </div>
      <div className="category-nav">
        <Link
          href="/"
          className="category-nav-all"
          title={`浏览全部${title}`}
        >
          <Icon name="grid" />
          <span>全部</span>
        </Link>
        {categories.map((category) => (
          <Link
            key={category.id}
            href={`/category/${category.id}`}
            className="category-nav-link"
            data-active={activeId === category.id ? "true" : "false"}
            style={{ "--tone": category.color } as React.CSSProperties}
            title={category.description}
          >
            <CategoryIcon id={category.id} />
            <span>{category.label}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}

export function CategoryNav({
  activeId,
  className = "",
}: {
  activeId?: CategoryId;
  className?: string;
}) {
  return (
    <div className={`board-navigation ${className}`}>
      <nav className="category-directory" aria-label="分类导航">
        <Link
          href="/"
          className="category-root-all"
          aria-current={activeId ? undefined : "page"}
          title="浏览全部活动和通知"
        >
          <Icon name="grid" />
          <span>全部</span>
        </Link>
        <div className="category-clusters">
          <Cluster
            title="活动"
            icon="calendar"
            categories={ACTIVITY_CATEGORIES}
            activeId={activeId}
          />
          <Cluster
            title="通知"
            icon="bell"
            categories={NOTICE_CATEGORIES}
            activeId={activeId}
          />
        </div>
      </nav>
    </div>
  );
}
