import { CATEGORY_MAP } from "@/lib/categories";
import { formatAbsolute } from "@/lib/format";
import type { Notice } from "@/lib/types";
import { TimeAgo } from "./time-ago";

function coverGlyph(title: string, fallback: string) {
  const cleaned = title
    .replace(/^[\s【\[（(《「“"'‘]+/, "")
    .replace(
      /^(?:20\d{2}[-./年]\d{1,2}[-./月]\d{1,2}日?|\d{1,2}月\d{1,2}日)\s*/,
      "",
    )
    .replace(/^(?:报|通知|公告|讲座|论坛|活动|预告)[:：\s]*/, "")
    .trim();
  const cjk = cleaned.match(/[\u4e00-\u9fff]/);
  if (cjk) return cjk[0];
  const latin = cleaned.match(/[A-Za-z0-9]/);
  return latin ? latin[0] : fallback;
}

function coverStyle(id: string, color: string) {
  const seed = Array.from(id).reduce(
    (total, char) => total + char.charCodeAt(0),
    0,
  );
  const angle = [120, 135, 150][seed % 3];
  const glyphX = 24 + (seed % 40);
  const glyphY = 20 + (seed % 30);

  return {
    backgroundImage: [
      `radial-gradient(circle at ${glyphX}% ${glyphY}%, color-mix(in srgb, ${color} 26%, transparent) 0 16%, transparent 17%)`,
      `repeating-linear-gradient(115deg, color-mix(in srgb, ${color} 7%, transparent) 0 2px, transparent 2px 14px)`,
      `linear-gradient(${angle}deg, color-mix(in srgb, ${color} 16%, #fff) 0%, color-mix(in srgb, ${color} 5%, #f7f8fa) 65%, #fff 100%)`,
    ].join(", "),
  };
}

export function NoticeCard({ notice }: { notice: Notice }) {
  const category = CATEGORY_MAP[notice.category];
  const color = category?.color ?? "#a51c30";
  const glyph = coverGlyph(
    notice.title,
    (notice.source_name || notice.title).trim().slice(0, 1),
  );

  return (
    <a
      href={notice.url}
      target="_blank"
      rel="noopener noreferrer"
      className="notice-block"
      title={notice.title}
      data-published={notice.published_at}
      data-source={notice.source_name}
    >
      <span className="notice-cover" style={coverStyle(notice.id, color)}>
        {notice.cover_image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={notice.cover_image}
            alt=""
            loading="lazy"
            referrerPolicy="no-referrer"
            className="absolute inset-0 h-full w-full object-cover"
          />
        ) : (
          <span className="notice-cover-glyph" style={{ color }}>
            {glyph}
          </span>
        )}
      </span>
      <span className="notice-body">
        <span className="notice-title">
          {notice.requires_registration ? (
            <span className="registration-badge" title="需报名">
              报
            </span>
          ) : null}
          {notice.title}
        </span>
        <span className="notice-meta">
          {notice.event_start ? (
            <time
              dateTime={notice.event_start}
              className="shrink-0"
              title="活动时间"
            >
              {formatAbsolute(notice.event_start)}
            </time>
          ) : (
            <TimeAgo iso={notice.published_at} />
          )}
          <span className="source" title={notice.source_name}>
            {notice.source_name}
          </span>
        </span>
      </span>
    </a>
  );
}
