"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Icon } from "./icons";

type IconName = React.ComponentProps<typeof Icon>["name"];

interface Option {
  value: string;
  label: string;
  href?: string;
}

export function ToolbarSelect({
  icon,
  options,
  defaultValue,
  onChange,
  target,
}: {
  icon: IconName;
  options: Option[];
  defaultValue?: string;
  onChange?: (value: string) => void;
  target?: "columns" | "sort";
}) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(defaultValue ?? options[0]?.value ?? "");
  const ref = useRef<HTMLDivElement>(null);
  const selected = options.find((option) => option.value === value);

  useEffect(() => {
    if (!open) return;
    const handlePointer = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", handlePointer);
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("mousedown", handlePointer);
      document.removeEventListener("keydown", handleKey);
    };
  }, [open]);

  return (
    <div className="toolbar-select" ref={ref}>
      <button
        type="button"
        className="toolbar-trigger"
        aria-haspopup="menu"
        aria-expanded={open}
        data-open={open ? "true" : "false"}
        onClick={() => setOpen((current) => !current)}
      >
        <Icon name={icon} />
        <span>{selected?.label ?? "选择"}</span>
        <Icon name="chevron-down" className="toolbar-chevron" />
      </button>

      {open ? (
        <div className="toolbar-menu" role="menu">
          {options.map((option) =>
            option.href ? (
              <Link
                key={option.value}
                href={option.href}
                className="toolbar-menu-item"
                role="menuitem"
                onClick={() => setOpen(false)}
              >
                <span>{option.label}</span>
              </Link>
            ) : (
              <button
                key={option.value}
                type="button"
                role="menuitemradio"
                aria-checked={value === option.value}
                className="toolbar-menu-item"
                data-selected={value === option.value ? "true" : "false"}
                onClick={() => {
                  setValue(option.value);
                  if (target === "columns") {
                    document.documentElement.dataset.columns = option.value;
                  }
                  if (target === "sort") {
                    window.dispatchEvent(
                      new CustomEvent("sjtuknow:sort", {
                        detail: option.value,
                      }),
                    );
                  }
                  onChange?.(option.value);
                  setOpen(false);
                }}
              >
                <span>{option.label}</span>
                {value === option.value ? (
                  <Icon name="check" className="h-3.5 w-3.5" />
                ) : null}
              </button>
            ),
          )}
        </div>
      ) : null}
    </div>
  );
}
