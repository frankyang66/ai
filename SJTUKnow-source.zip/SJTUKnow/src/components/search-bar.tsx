import { Icon } from "./icons";

export function SearchBar({
  defaultValue = "",
  autoFocus = false,
  placeholder = "搜索标题、公众号或发布单位",
}: {
  defaultValue?: string;
  autoFocus?: boolean;
  placeholder?: string;
}) {
  return (
    <form action="/search" method="get" role="search" className="relative w-full">
      <Icon
        name="search"
        className="pointer-events-none absolute left-3.5 top-1/2 h-[17px] w-[17px] -translate-y-1/2 text-muted-foreground"
      />
      <input
        type="search"
        name="q"
        defaultValue={defaultValue}
        autoFocus={autoFocus}
        placeholder={placeholder}
        aria-label="搜索通知"
        className="h-[42px] w-full rounded-xl border border-input bg-card pl-[42px] pr-4 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary/50 focus:ring-4 focus:ring-primary/10"
      />
    </form>
  );
}
