"use client";

import { useSyncExternalStore } from "react";
import {
  getOverrides,
  getServerOverrides,
  mergeSources,
  removeManagedSource,
  restoreManagedSource,
  subscribeOverrides,
  type ManagedSource,
} from "@/lib/source-overrides";
import {
  clearApiKey,
  getApiKey,
  getServerApiKey,
  saveApiKey,
  subscribeApiKey,
} from "@/lib/llm-key";
import { Icon } from "./icons";
import { SourceStatusBadge } from "./source-status-badge";
import { SourcesAssistant } from "./sources-assistant";

function SourceRow({
  source,
  muted = false,
}: {
  source: ManagedSource;
  muted?: boolean;
}) {
  return (
    <li
      className={`flex items-center justify-between gap-3 py-2.5 ${
        muted ? "opacity-75" : ""
      }`}
    >
      <div className="flex min-w-0 items-start gap-2">
        <span className="pt-1">
          <SourceStatusBadge source={source} />
        </span>
        <div className="min-w-0">
          <p className="flex items-center gap-1.5 truncate text-sm font-semibold text-foreground">
            {source.name}
            {source.id.startsWith("custom_") ? (
              <span className="rounded-md bg-accent px-1.5 py-0.5 text-[10px] font-semibold text-primary">
                自定义
              </span>
            ) : null}
          </p>
          <p className="mt-0.5 truncate text-xs text-muted-foreground">
            {source.type === "wechat" ? "微信公众号" : "官方网站"}
            {source.homepage ? ` · ${source.homepage}` : ""}
          </p>
        </div>
      </div>
      <button
        type="button"
        onClick={() => removeManagedSource(source.id)}
        className="shrink-0 rounded-lg border border-border bg-card px-2.5 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
      >
        删除
      </button>
    </li>
  );
}

export function SourceManagerPanel({
  sources,
}: {
  sources: ManagedSource[];
}) {
  const overrides = useSyncExternalStore(
    subscribeOverrides,
    getOverrides,
    getServerOverrides,
  );
  const apiKey = useSyncExternalStore(
    subscribeApiKey,
    getApiKey,
    getServerApiKey,
  );
  const merged = mergeSources(sources, overrides);
  const hiddenSources = sources.filter((source) =>
    overrides.hidden.includes(source.id),
  );
  const unfetchable = merged.filter(
    (source) => source.type === "wechat" && source.count === 0,
  );
  const fetchable = merged.filter(
    (source) => !(source.type === "wechat" && source.count === 0),
  );

  return (
    <div>
      <div className="rounded-xl bg-muted p-3">
        <label
          htmlFor="manager-deepseek-key"
          className="mb-1.5 block text-xs font-semibold text-foreground"
        >
          DeepSeek API Key
        </label>
        <div className="flex items-center gap-2">
          <input
            id="manager-deepseek-key"
            type="password"
            value={apiKey}
            onChange={(event) => saveApiKey(event.target.value)}
            placeholder="sk-…（自动保存）"
            autoComplete="off"
            spellCheck={false}
            className="h-10 min-w-0 flex-1 rounded-xl border border-input bg-background px-3 text-sm outline-none placeholder:text-muted-foreground/60 focus:border-primary/50 focus:ring-4 focus:ring-primary/10"
          />
          {apiKey ? (
            <button
              type="button"
              onClick={clearApiKey}
              className="shrink-0 rounded-lg border border-border bg-card px-2.5 py-1.5 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
            >
              删除
            </button>
          ) : null}
        </div>
        <p className="mt-1.5 text-[11px] text-muted-foreground">
          {apiKey
            ? "已自动保存，仅用于调用 DeepSeek 接口。"
            : "填写后自动保存，仅本机可见。"}
        </p>
      </div>

      <div className="mt-4">
        <SourcesAssistant sources={merged} />
      </div>

      <div className="mt-6 border-t border-border pt-4">
        <h3 className="text-sm font-bold text-foreground">
          当前来源
          <span className="ml-1.5 text-xs font-medium text-muted-foreground">
            {merged.length}
          </span>
        </h3>

        <h4 className="mt-4 text-xs font-semibold text-muted-foreground">
          可获取
          <span className="ml-1.5 font-medium">{fetchable.length}</span>
        </h4>
        <ul className="mt-1 divide-y divide-border">
          {fetchable.length > 0 ? (
            fetchable.map((source) => (
              <SourceRow key={source.id} source={source} />
            ))
          ) : (
            <li className="py-4 text-sm text-muted-foreground">暂无来源</li>
          )}
        </ul>

        {unfetchable.length > 0 ? (
          <>
            <h4 className="mt-5 text-xs font-semibold text-muted-foreground">
              未接入抓取
              <span className="ml-1.5 font-medium">{unfetchable.length}</span>
            </h4>
            <ul className="mt-1 divide-y divide-border">
              {unfetchable.map((source) => (
                <SourceRow key={source.id} source={source} muted />
              ))}
            </ul>
          </>
        ) : null}
      </div>

      {hiddenSources.length > 0 ? (
        <div className="mt-4 border-t border-border pt-3">
          <h3 className="text-xs font-semibold text-muted-foreground">
            已隐藏
            <span className="ml-1.5">{hiddenSources.length}</span>
          </h3>
          <ul className="mt-1 divide-y divide-border">
            {hiddenSources.map((source) => (
              <li
                key={source.id}
                className="flex items-center justify-between gap-3 py-2"
              >
                <span className="truncate text-sm text-muted-foreground">
                  {source.name}
                </span>
                <button
                  type="button"
                  onClick={() => restoreManagedSource(source.id)}
                  className="shrink-0 rounded-lg border border-border bg-card px-2.5 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
                >
                  恢复
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <p className="mt-4 flex items-center gap-1.5 text-[11px] text-muted-foreground">
        <Icon name="database" className="h-3.5 w-3.5" />
        本地存储，刷新后仍会保留
      </p>
    </div>
  );
}
