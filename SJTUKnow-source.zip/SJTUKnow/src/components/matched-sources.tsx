"use client";

import { useMemo, useSyncExternalStore } from "react";
import { SourceStatusBadge } from "./source-status-badge";
import {
  getOverrides,
  getServerOverrides,
  mergeSources,
  subscribeOverrides,
  type ManagedSource,
} from "@/lib/source-overrides";

function canonicalName(value: string) {
  return value
    .replace(/上海交通大学|上海交大|交大/g, "")
    .replace(/\s+/g, "")
    .toLowerCase();
}

export function MatchedSources({
  query,
  sources,
}: {
  query: string;
  sources: ManagedSource[];
}) {
  const overrides = useSyncExternalStore(
    subscribeOverrides,
    getOverrides,
    getServerOverrides,
  );
  const merged = useMemo(
    () => mergeSources(sources, overrides),
    [sources, overrides],
  );

  const keyword = query.trim().toLowerCase();

  const matches = useMemo(() => {
    if (!keyword) return [];
    const canonicalKeyword = canonicalName(keyword);
    return merged
      .filter((source) => {
        const hay = `${source.name} ${source.unit} ${
          source.wechat_id ?? ""
        }`.toLowerCase();
        return (
          hay.includes(keyword) ||
          (canonicalKeyword.length >= 2 &&
            canonicalName(hay).includes(canonicalKeyword))
        );
      })
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name, "zh"))
      .slice(0, 6);
  }, [merged, keyword]);

  if (matches.length === 0) return null;

  return (
    <section className="mt-6">
      <div className="feed-toolbar">
        <h2 className="feed-title">
          相关信息源
          <span className="feed-count">{matches.length}</span>
        </h2>
      </div>
      <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
        {matches.map((source) => {
          const href = source.listing_url ?? source.homepage;
          return (
            <li
              key={source.id}
              className="flex items-center justify-between gap-4 px-4 py-3"
            >
              <div className="min-w-0">
                <p className="flex flex-wrap items-center gap-1.5 truncate text-sm font-semibold text-foreground">
                  <SourceStatusBadge source={source} />
                  {source.name}
                  <span className="rounded-md border border-border bg-background px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">
                    {source.type === "wechat" ? "公众号" : "官网"}
                  </span>
                </p>
              </div>
              {href ? (
                <a
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="shrink-0 rounded-lg border border-border bg-card px-2.5 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:border-input hover:text-primary"
                >
                  查看
                </a>
              ) : null}
            </li>
          );
        })}
      </ul>
    </section>
  );
}
