"use client";

import { useEffect } from "react";

export function SortListener() {
  useEffect(() => {
    const handleSort = (event: Event) => {
      const mode = (event as CustomEvent<string>).detail;
      const grids = document.querySelectorAll<HTMLElement>(".waterfall-grid");
      for (const grid of grids) {
        const cards = Array.from(grid.children) as HTMLElement[];
        cards.sort((a, b) => {
          if (mode === "source") {
            return (a.dataset.source ?? "").localeCompare(
              b.dataset.source ?? "",
              "zh",
            );
          }
          return (b.dataset.published ?? "").localeCompare(
            a.dataset.published ?? "",
          );
        });
        for (const card of cards) grid.appendChild(card);
      }
    };

    window.addEventListener("sjtuknow:sort", handleSort);
    return () => window.removeEventListener("sjtuknow:sort", handleSort);
  }, []);

  return null;
}
