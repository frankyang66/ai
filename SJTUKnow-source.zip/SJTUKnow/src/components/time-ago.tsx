"use client";

import { useSyncExternalStore } from "react";
import { formatAbsolute, formatRelative } from "@/lib/format";

let current = Date.now();
const listeners = new Set<() => void>();
let timer: ReturnType<typeof setInterval> | null = null;

function subscribe(listener: () => void) {
  listeners.add(listener);
  if (timer === null) {
    timer = setInterval(() => {
      current = Date.now();
      for (const item of listeners) item();
    }, 60_000);
  }
  return () => {
    listeners.delete(listener);
    if (listeners.size === 0 && timer !== null) {
      clearInterval(timer);
      timer = null;
    }
  };
}

export function TimeAgo({
  iso,
  className,
}: {
  iso: string;
  className?: string;
}) {
  const now = useSyncExternalStore(
    subscribe,
    () => current,
    () => null,
  );
  const label = now === null ? formatAbsolute(iso) : formatRelative(iso, now);

  return (
    <time dateTime={iso} className={className} suppressHydrationWarning>
      {label}
    </time>
  );
}
