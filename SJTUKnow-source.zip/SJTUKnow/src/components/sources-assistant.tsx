"use client";

import { useMemo, useState, useSyncExternalStore } from "react";
import {
  CATEGORIES,
  VISIBLE_CATEGORY_IDS,
  isVisibleCategory,
} from "@/lib/categories";
import {
  addBoard,
  assignSource,
  getBoardState,
  getServerBoardState,
  removeBoard,
  subscribeBoards,
} from "@/lib/board-store";
import { getApiKey, getServerApiKey, subscribeApiKey } from "@/lib/llm-key";
import {
  appendTurn,
  clearHistory,
  getHistory,
  getServerHistory,
  subscribeHistory,
} from "@/lib/chat-store";
import {
  addCustomSource,
  type ManagedSource,
} from "@/lib/source-overrides";
import { Icon } from "./icons";

interface Suggestion {
  name: string;
  url: string;
  type: "official_site" | "wechat";
  reason: string;
  verification?: "ok" | "fail" | "unknown";
}

interface BoardAction {
  type: "add_board" | "remove_board" | "assign_source";
  label?: string;
  color?: string;
  board?: string;
  source?: string;
  boards?: string[];
}

interface AssistantResult {
  reply: string;
  sources: Suggestion[];
  board_actions: BoardAction[];
}

function normalize(value: string) {
  return value
    .replace(/[\s·|｜:：,，。.()（）\[\]【】「」]/g, "")
    .toLowerCase();
}

function parseResult(raw: string): AssistantResult {
  let text = raw.trim();
  const fenced = /```(?:json)?\s*([\s\S]*?)```/i.exec(text);
  if (fenced) text = fenced[1].trim();
  try {
    const data = JSON.parse(text) as {
      reply?: unknown;
      sources?: unknown;
      board_actions?: unknown;
    };
    const sources = (Array.isArray(data.sources) ? data.sources : [])
      .slice(0, 12)
      .map((item) => item as Record<string, unknown>)
      .map((item) => ({
        name: String(item.name ?? "").trim().slice(0, 80),
        url: String(item.url ?? "").trim(),
        type:
          item.type === "wechat"
            ? ("wechat" as const)
            : ("official_site" as const),
        reason: String(item.reason ?? "").trim().slice(0, 200),
      }))
      .filter(
        (item) => item.name.length > 0 && /^https?:\/\//i.test(item.url),
      );

    const board_actions = (
      Array.isArray(data.board_actions) ? data.board_actions : []
    )
      .slice(0, 10)
      .map((item) => item as Record<string, unknown>)
      .filter((item) =>
        ["add_board", "remove_board", "assign_source"].includes(
          String(item.type),
        ),
      )
      .map((item) => ({
        type: String(item.type) as BoardAction["type"],
        label: item.label ? String(item.label).slice(0, 20) : undefined,
        color: item.color ? String(item.color) : undefined,
        board: item.board ? String(item.board).slice(0, 20) : undefined,
        source: item.source ? String(item.source).slice(0, 100) : undefined,
        boards: Array.isArray(item.boards)
          ? item.boards.map((board) => String(board).slice(0, 20))
          : undefined,
      }));

    return {
      reply: String(data.reply ?? "").trim() || "已处理。",
      sources,
      board_actions,
    };
  } catch {
    return { reply: "", sources: [], board_actions: [] };
  }
}

const PLANNER_PROMPT = `你是搜索规划助手。用户想找信息源、招聘或活动信息。请把需求改写成 3-8 条适合中文搜索引擎的短查询。
如果用户给出明确名称（社团、协会、公司、公众号等），搜索词必须包含该完整名称，不要扩展到无关机构或改写成泛称。
每条查询只写「机构名 招聘」或「机构名 校园招聘」，不要加“研究所/官网/实习”等其他词；使用机构当前名称并写全称以避免歧义（例如国泰海通证券）。
如果用户说的是泛称（例如“证券研究所”），请至少覆盖以下六家：中信证券、中信建投、中金公司、华泰证券、国泰海通证券、广发证券，每家一条查询；如有需要可再补充其他头部机构。
只返回严格 JSON：{"queries":["查询1","查询2","查询3"]}`;

function rankWebResults<
  T extends { title: string; url: string; snippet: string },
>(query: string, results: T[]): Array<T & { score: number }> {
  const tokens = query
    .split(/\s+/)
    .map((token) => token.trim().toLowerCase())
    .filter(Boolean);

  return results
    .map((result) => {
      const hay = `${result.title} ${result.url} ${result.snippet}`.toLowerCase();
      let score = 0;
      for (const token of tokens) {
        if (token.length >= 2 && hay.includes(token)) score += 3;
      }
      if (
        /招聘|career|job|wecruit|hotjob|zhiye|人才|校招|campus|recruit/.test(
          hay,
        )
      ) {
        score += 5;
      }
      if (/careers\.|job\.|zhiye|wecruit|hotjob|talent|hr\./.test(hay)) {
        score += 3;
      }
      if (
        /(citics|cicc|csc108|htsc|htsec|gtht|gtja|gf\.com|citics\.com)\./.test(
          hay,
        )
      ) {
        score += 4;
      }
      if (
        /hahazhao|jinliqiuzhi|yingjiesheng|zhaopin|zhipin|niuqizp|campus\.51job/.test(
          hay,
        )
      ) {
        score -= 2;
      }
      if (
        /baike|zhihu|wenda|baijiahao|sohu|sina|eastmoney|news|finance\.sina/.test(
          hay,
        )
      ) {
        score -= 4;
      }
      if (
        /银行|bank|保险|航空|cathay|集团官网/.test(hay) &&
        !/证券|基金/.test(hay)
      ) {
        score -= 4;
      }
      return { ...result, score };
    })
    .sort((a, b) => b.score - a.score);
}

function fallbackQueries(text: string): string[] {
  const base = text.replace(/[?？。.]/g, "").trim();
  const queries = new Set<string>([base]);
  if (/招聘|实习|就业|求职|校招/.test(text)) {
    queries.add(`${base} 招聘`);
    if (!/校园|校招/.test(text)) queries.add(`${base} 校园招聘`);
  }
  return Array.from(queries).filter(Boolean).slice(0, 3);
}

const STOP_GRAMS = new Set([
  "上海",
  "交通",
  "大学",
  "交大",
  "学院",
  "学校",
  "官网",
  "网站",
  "官方",
  "信息",
  "通知",
  "公告",
  "服务",
  "系统",
  "中心",
  "平台",
]);

function queryGrams(query: string): string[] {
  const clean = query.replace(
    /[\s，。！？,.!?、:：;；()（）\[\]【】「」"'“”]/g,
    "",
  );
  const grams = new Set<string>();
  for (let index = 0; index < clean.length - 1; index += 1) {
    const gram = clean.slice(index, index + 2);
    if (!/^[\u4e00-\u9fff]{2}$/.test(gram)) continue;
    if (STOP_GRAMS.has(gram)) continue;
    grams.add(gram);
  }
  if (clean.length >= 2 && !STOP_GRAMS.has(clean)) grams.add(clean);
  return Array.from(grams);
}

function matchesTarget(
  query: string,
  result: { title: string; url: string; snippet: string },
): boolean {
  const grams = queryGrams(query);
  if (grams.length === 0) return true;
  const hay = `${result.title} ${result.url} ${result.snippet}`;
  return grams.some((gram) => hay.includes(gram));
}

const COVERAGE_GROUPS: Array<{ test: RegExp; queries: string[] }> = [
  {
    test: /证券研究所|券商研究所|证券研究|券商研究/,
    queries: [
      "中信证券 招聘",
      "中信建投证券 招聘",
      "中金公司 招聘",
      "华泰证券 招聘",
      "国泰海通证券 招聘",
      "广发证券 招聘",
    ],
  },
];

function parseQueries(raw: string): string[] {
  let text = raw.trim();
  const fenced = /```(?:json)?\s*([\s\S]*?)```/i.exec(text);
  if (fenced) text = fenced[1].trim();
  try {
    const data = JSON.parse(text) as { queries?: unknown };
    if (!Array.isArray(data.queries)) return [];
    return data.queries
      .map((item) => String(item).trim())
      .filter((item) => item.length >= 2 && item.length <= 40)
      .slice(0, 8);
  } catch {
    return [];
  }
}

export function SourcesAssistant({
  sources,
  initialPrompt = "",
}: {
  sources: ManagedSource[];
  initialPrompt?: string;
}) {
  const apiKey = useSyncExternalStore(
    subscribeApiKey,
    getApiKey,
    getServerApiKey,
  );
  const boardState = useSyncExternalStore(
    subscribeBoards,
    getBoardState,
    getServerBoardState,
  );
  const history = useSyncExternalStore(
    subscribeHistory,
    getHistory,
    getServerHistory,
  );
  const [prompt, setPrompt] = useState(initialPrompt);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [reply, setReply] = useState("");
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [addedUrls, setAddedUrls] = useState<Set<string>>(new Set());
  const [boardNotes, setBoardNotes] = useState<string[]>([]);

  const boards = useMemo(
    () => [
      ...VISIBLE_CATEGORY_IDS.flatMap((id) => {
        const category = CATEGORIES.find((item) => item.id === id);
        if (
          !category ||
          !isVisibleCategory(category.id) ||
          boardState.hidden.includes(category.id)
        ) {
          return [];
        }
        return [{ id: category.id as string, label: category.label }];
      }),
      ...boardState.custom.map((board) => ({
        id: board.id,
        label: board.label,
      })),
    ],
    [boardState],
  );

  const applyBoardActions = (actions: BoardAction[]) => {
    const notes: string[] = [];
    const boardMap = new Map(
      boards.map((board) => [board.label, board.id] as const),
    );

    for (const action of actions) {
      if (action.type === "add_board" && action.label) {
        if (boardMap.has(action.label)) {
          notes.push(`板块「${action.label}」已存在`);
          continue;
        }
        const created = addBoard(action.label, action.color ?? "#a51c30");
        boardMap.set(created.label, created.id);
        notes.push(`新增板块「${created.label}」`);
      } else if (action.type === "remove_board" && action.board) {
        const boardId =
          boardMap.get(action.board) ??
          boards.find((board) => board.id === action.board)?.id;
        if (!boardId) {
          notes.push(`未找到板块「${action.board}」`);
          continue;
        }
        removeBoard(boardId);
        boardMap.delete(action.board);
        notes.push(`删除板块「${action.board}」`);
      } else if (
        action.type === "assign_source" &&
        action.source &&
        action.boards?.length
      ) {
        const target = normalize(action.source);
        const matched =
          sources.find((source) => normalize(source.name) === target) ??
          sources.find((source) => {
            const name = normalize(source.name);
            return name.includes(target) || target.includes(name);
          });
        if (!matched) {
          notes.push(`未找到来源「${action.source}」`);
          continue;
        }
        const boardIds = action.boards
          .map((name) => boardMap.get(name))
          .filter((id): id is string => Boolean(id));
        if (boardIds.length === 0) {
          notes.push(`未找到板块「${action.boards.join("、")}」`);
          continue;
        }
        assignSource(matched.id, boardIds);
        notes.push(`将「${matched.name}」归入 ${action.boards.join("、")}`);
      }
    }
    return notes;
  };

  const run = async (event: React.FormEvent) => {
    event.preventDefault();
    const key = apiKey.trim();
    const text = prompt.trim();
    if (!key) {
      setError("请先在「来源管理」中设置 DeepSeek API Key。");
      return;
    }
    if (!text) return;

    setLoading(true);
    setError("");
    setReply("");
    setSuggestions([]);
    setBoardNotes([]);

    const historyContext = history
      .slice(-8)
      .map(
        (message) =>
          `${message.role === "user" ? "用户" : "助手"}：${message.content}`,
      )
      .join("\n");

    const wantsBoardAction = /板块|分类|归入|布局|删除|新增/.test(text);
    let webResults: Array<{
      title: string;
      url: string;
      snippet: string;
      score?: number;
    }> = [];
    let coverageResults: Array<{
      title: string;
      url: string;
      snippet: string;
      score?: number;
    }> = [];


    if (!wantsBoardAction) {
      let queries = fallbackQueries(text);
      try {
        const planController = new AbortController();
        const planTimer = setTimeout(() => planController.abort(), 45000);
        const planResponse = await fetch(
          "https://api.deepseek.com/chat/completions",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${key}`,
            },
            body: JSON.stringify({
              model: "deepseek-flash",
              reasoning_effort: "high",
              temperature: 0.2,
              max_tokens: 3000,
              response_format: { type: "json_object" },
              messages: [
                { role: "system", content: PLANNER_PROMPT },
                {
                  role: "user",
                  content: historyContext
                    ? `对话上下文：\n${historyContext}\n\n当前需求：${text}`
                    : text,
                },
              ],
            }),
            signal: planController.signal,
          },
        );
        clearTimeout(planTimer);
        if (planResponse.ok) {
          const planData = await planResponse.json();
          const planned = parseQueries(
            planData?.choices?.[0]?.message?.content ?? "",
          );
          if (planned.length > 0) queries = planned.slice(0, 3);
        }
      } catch {
        // Fall back to simple expanded queries.
      }

      const coverageGroup = COVERAGE_GROUPS.find((group) =>
        group.test.test(text),
      );
      if (coverageGroup) {
        queries = Array.from(
          new Set([...coverageGroup.queries, ...queries]),
        );
      }
      const activeQueries = queries.slice(0, 6);
      const runSearch = async (query: string) => {
        try {
          const response = await fetch(
            `/api/web-search?q=${encodeURIComponent(query)}`,
          );
          if (!response.ok) return [];
          const data = await response.json();
          return Array.isArray(data.results) ? data.results : [];
        } catch {
          return [];
        }
      };

      // Search in small batches to avoid Bing rate limiting.
      const searchResults: Array<
        Array<{ title: string; url: string; snippet: string }>
      > = [];
      for (let index = 0; index < activeQueries.length; index += 3) {
        const batch = activeQueries.slice(index, index + 3);
        const batchResults = await Promise.all(
          batch.map(async (query) => {
            let results = await runSearch(query);
            if (results.length === 0) {
              await new Promise((resolve) => setTimeout(resolve, 800));
              results = await runSearch(query);
            }
            return results;
          }),
        );
        searchResults.push(...batchResults);
        if (index + 3 < activeQueries.length) {
          await new Promise((resolve) => setTimeout(resolve, 500));
        }
      }

      const merged = new Map<
        string,
        { title: string; url: string; snippet: string; score: number }
      >();
      const coverage: Array<{
        title: string;
        url: string;
        snippet: string;
        score: number;
      }> = [];

      searchResults.forEach((results, index) => {
        const query = activeQueries[index] ?? text;
        const relevant = results.filter((item) => matchesTarget(query, item));
        const ranked = rankWebResults(query, relevant);
        const best = ranked[0];
        if (best) coverage.push(best);
        for (const item of ranked) {
          const existing = merged.get(item.url);
          if (!existing || item.score > existing.score) {
            merged.set(item.url, item);
          }
        }
      });

      webResults = Array.from(merged.values())
        .sort((a, b) => b.score - a.score)
        .filter((item) => item.score >= 1)
        .slice(0, 20);
      coverageResults = coverage;
    }

    const webContext = webResults
      .map(
        (item, index) =>
          `${index + 1}. ${item.title} | ${item.url} | ${item.snippet ?? ""}`,
      )
      .join("\n");

    const knownCatalog = sources
      .filter((source) => source.listing_url || source.homepage)
      .slice(0, 160)
      .map(
        (source) =>
          `- ${source.name} | ${
            source.type === "wechat" ? "wechat" : "official_site"
          } | ${source.listing_url ?? source.homepage}`,
      )
      .join("\n");
    const boardList = boards.map((board) => board.label).join("、");

    const systemPrompt = `你是「交大知道」的信息来源与板块助手。用户会用自然语言让你找信息源，或调整信息来源页的板块布局。
当前板块：${boardList}
已知来源目录（优先从中挑选，避免重复；这些 URL 已核验）：
${knownCatalog}

实时网络搜索结果（来自 Bing，可能不完整，需核对）：
${webContext || "（无）"}

只返回严格 JSON，不要输出 Markdown 代码块：
{"reply":"简短中文说明","sources":[{"name":"来源名称","url":"https://example.com/list","type":"official_site|wechat","reason":"推荐理由"}],"board_actions":[{"type":"add_board","label":"板块名","color":"#a51c30"},{"type":"remove_board","board":"板块名"},{"type":"assign_source","source":"来源名","boards":["板块名"]}]}

规则：
- 你是负责“确定链接”的快速模型：先从实时网络搜索结果中挑出与用户需求最相关的真实页面，再结合本地目录回答。
- 优先 careers.* / 招聘官网 / 人才招聘 / 校园招聘 专页；不要推荐集团首页、银行首页、百科、知乎、问答或新闻聚合；同一页面只保留一次。
- 如果用户问的是泛称（例如“证券研究所”），请给出多家相关机构的官方招聘页，而不是只回答本地目录没有。
- 即使本地目录有来源，只要网络结果更直接回答问题，也要把相关网络页面放进 sources 推荐。
- 只推荐真实存在、可公开访问的网址；不确定就不要编造。
- 网址尽量给具体列表页；公众号文章链接 type 填 wechat。
- 找来源时返回 sources（6-12 个）；如果用户问的是证券研究所等泛称，要覆盖三中一华、国泰海通证券、广发证券等主要机构，每家优先官方招聘页。
- 调整板块时返回 board_actions；不要两者强行都填。
- 板块动作最多 10 个；来源名尽量与目录中的名称一致。
- 只在用户明确要求新增/删除板块、或把某个已存在来源归入板块时返回 board_actions；单纯找来源时不要生成板块动作。
- 不要推荐需要登录才能查看的内容。
- 不要推荐与需求无关的页面（纪录片、影视、新闻、百科、问答等）。`;

    try {
      const response = await fetch(
        "https://api.deepseek.com/chat/completions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${key}`,
          },
          body: JSON.stringify({
            model: "deepseek-flash",
            reasoning_effort: "high",
            temperature: 0.3,
            max_tokens: 5000,
            response_format: { type: "json_object" },
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: text },
            ],
          }),
        },
      );
      const data = await response.json();
      if (!response.ok) {
        throw new Error(
          data?.error?.message ?? `请求失败（${response.status}）`,
        );
      }
      const content: string = data?.choices?.[0]?.message?.content ?? "";
      const result = parseResult(content);
      if (result.sources.length === 0 && webResults.length > 0) {
        result.sources = webResults.slice(0, 4).map((item) => ({
          name: item.title.slice(0, 80),
          url: item.url,
          type: "official_site" as const,
          reason: item.snippet.slice(0, 200),
        }));
      }
      if (!result.reply && result.sources.length === 0 && result.board_actions.length === 0) {
        throw new Error("DS 没有返回可用结果，请换个说法再试。");
      }

      const notes = applyBoardActions(result.board_actions);
      const webTop = webResults.slice(0, 3);
      const seenUrls = new Set<string>();
      const candidates: Suggestion[] = [];
      const pushCandidate = (item: Suggestion) => {
        if (!item?.url || seenUrls.has(item.url)) return;
        seenUrls.add(item.url);
        candidates.push(item);
      };

      // Coverage first: one best result per planned institution query.
      for (const item of coverageResults) {
        pushCandidate({
          name: item.title.slice(0, 80),
          url: item.url,
          type: "official_site",
          reason: item.snippet.slice(0, 200),
        });
      }
      for (const item of result.sources) pushCandidate(item);
      for (const item of webTop) {
        pushCandidate({
          name: item.title.slice(0, 80),
          url: item.url,
          type: "official_site",
          reason: item.snippet.slice(0, 200),
        });
      }
      const limitedCandidates = candidates.slice(0, 18);

      const verifiedAll: Suggestion[] = await Promise.all(
        limitedCandidates.map(async (suggestion) => {
          try {
            const check = await fetch(
              `/api/verify-url?url=${encodeURIComponent(suggestion.url)}`,
            );
            if (!check.ok) {
              return { ...suggestion, verification: "unknown" as const };
            }
            const info = await check.json();
            return {
              ...suggestion,
              verification: info.ok ? ("ok" as const) : ("fail" as const),
            };
          } catch {
            return { ...suggestion, verification: "unknown" as const };
          }
        }),
      );

      const jobIntent = /招聘|实习|就业|求职|校招/.test(text);
      const baseTokens = text
        .replace(/招聘|实习|就业|求职|校招/g, "")
        .split(/\s+/)
        .map((token) => token.trim())
        .filter((token) => token.length >= 2);
      const verified = jobIntent
        ? verifiedAll.filter((item) => {
            const hay = `${item.name} ${item.url} ${item.reason}`;
            return (
              /招聘|实习|career|job|zhiye|wecruit|hotjob|人才|校招|campus|recruit/.test(
                hay,
              ) ||
              baseTokens.some((token) => hay.includes(token))
            );
          })
        : verifiedAll;
      const finalSuggestions = verified.length > 0 ? verified : verifiedAll;

      appendTurn({ role: "user", content: text });
      appendTurn({
        role: "assistant",
        content: [
          result.reply,
          notes.length > 0 ? notes.map((note) => `· ${note}`).join("\n") : "",
          finalSuggestions.length > 0
            ? finalSuggestions
                .map((item) => `- ${item.name} | ${item.url}`)
                .join("\n")
            : "",
        ]
          .filter(Boolean)
          .join("\n"),
      });

      setReply(result.reply);
      setBoardNotes(notes);
      setSuggestions(finalSuggestions);
      setPrompt("");
      setAddedUrls(new Set());
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "请求失败，请检查 API Key 或网络。",
      );
    } finally {
      setLoading(false);
    }
  };

  const isAdded = (suggestion: Suggestion) =>
    addedUrls.has(suggestion.url) ||
    sources.some(
      (source) =>
        source.homepage === suggestion.url ||
        source.listing_url === suggestion.url ||
        source.name === suggestion.name,
    );

  const addSuggestion = (suggestion: Suggestion) => {
    const exists = sources.some(
      (source) =>
        source.homepage === suggestion.url ||
        source.listing_url === suggestion.url ||
        source.name === suggestion.name,
    );
    if (!exists) {
      addCustomSource({
        name: suggestion.name,
        url: suggestion.url,
        type: suggestion.type,
      });
    }
    setAddedUrls((current) => new Set(current).add(suggestion.url));
  };

  const addAll = () => {
    for (const suggestion of suggestions) {
      if (!isAdded(suggestion) && suggestion.verification !== "fail") {
        addSuggestion(suggestion);
      }
    }
  };

  return (
    <div>
      {history.length > 0 ? (
        <div className="mb-3">
          <div className="flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
            <span>已记住 {Math.ceil(history.length / 2)} 轮对话</span>
            <button
              type="button"
              onClick={clearHistory}
              className="rounded-lg border border-border bg-card px-2 py-1 text-[11px] font-semibold transition-colors hover:border-primary/40 hover:text-primary"
            >
              清空上下文
            </button>
          </div>
          <details className="mt-1.5 rounded-xl border border-border bg-muted/40 px-3 py-2 text-xs">
            <summary className="cursor-pointer select-none font-semibold text-muted-foreground">
              查看上下文（{history.length} 条）
            </summary>
            <div className="mt-2 max-h-40 space-y-2 overflow-y-auto">
              {history.slice(-6).map((message, index) => (
                <div key={`${message.at}-${index}`}>
                  <span className="font-semibold text-foreground">
                    {message.role === "user" ? "你" : "DS"}：
                  </span>
                  <span className="whitespace-pre-wrap text-muted-foreground">
                    {message.content}
                  </span>
                </div>
              ))}
            </div>
          </details>
        </div>
      ) : null}

      <form onSubmit={run}>
        <textarea
          value={prompt}
          onChange={(event) => setPrompt(event.target.value)}
          rows={5}
          autoFocus
          placeholder="告诉 DS：想找什么来源，或想怎样调整板块，例如「帮我找安泰经管学院的活动栏目」「新增一个实习板块，把 QuantEntry 放进去」"
          className="w-full resize-y rounded-2xl border border-input bg-background px-4 py-3 text-sm leading-relaxed outline-none placeholder:text-muted-foreground/60 focus:border-primary/50 focus:ring-4 focus:ring-primary/10"
        />
        <div className="mt-2 flex items-center justify-end">
          <button
            type="submit"
            disabled={loading || !apiKey.trim() || !prompt.trim()}
            className="inline-flex items-center gap-1.5 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-accent-foreground disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Icon name="sparkles" className="h-4 w-4" />
            {loading ? "处理中…" : "交给 DS"}
          </button>
        </div>
        {error ? <p className="mt-2 text-xs text-primary">{error}</p> : null}
      </form>

      {reply || boardNotes.length > 0 || suggestions.length > 0 ? (
        <div className="mt-4 rounded-xl border border-border p-3">
          {reply ? (
            <p className="text-sm leading-relaxed text-foreground/85">
              {reply}
            </p>
          ) : null}

          {boardNotes.length > 0 ? (
            <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
              {boardNotes.map((note, index) => (
                <li key={`${note}-${index}`}>· {note}</li>
              ))}
            </ul>
          ) : null}

          {suggestions.length > 0 ? (
            <div className="mt-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-foreground">
                  备选来源
                  <span className="ml-1.5 font-medium text-muted-foreground">
                    {suggestions.length}
                  </span>
                </span>
                <button
                  type="button"
                  onClick={addAll}
                  className="ml-auto rounded-lg bg-accent px-2.5 py-1 text-xs font-semibold text-primary"
                >
                  全部添加
                </button>
              </div>
              <ul className="mt-1 divide-y divide-border">
                {suggestions.map((suggestion) => (
                  <li
                    key={`${suggestion.name}-${suggestion.url}`}
                    className="py-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="flex flex-wrap items-center gap-1.5 text-sm font-semibold text-foreground">
                          {suggestion.name}
                          <span className="rounded-md border border-border bg-background px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">
                            {suggestion.type === "wechat" ? "公众号" : "官网"}
                          </span>
                          <span
                            className={`rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${
                              suggestion.verification === "ok"
                                ? "bg-[#e8f5ec] text-[#1f7a3a]"
                                : suggestion.verification === "fail"
                                  ? "bg-[#fdeaea] text-[#a51c30]"
                                  : "bg-muted text-muted-foreground"
                            }`}
                          >
                            {suggestion.verification === "ok"
                              ? "已验证"
                              : suggestion.verification === "fail"
                                ? "无法访问"
                                : "待核对"}
                          </span>
                        </p>
                        <a
                          href={suggestion.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-0.5 block truncate text-xs text-primary underline-offset-2 hover:underline"
                        >
                          {suggestion.url}
                        </a>
                        {suggestion.reason ? (
                          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                            {suggestion.reason}
                          </p>
                        ) : null}
                      </div>
                      <button
                        type="button"
                        disabled={
                          isAdded(suggestion) ||
                          suggestion.verification === "fail"
                        }
                        onClick={() => addSuggestion(suggestion)}
                        className="shrink-0 rounded-lg border border-border bg-card px-2.5 py-1 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary disabled:cursor-not-allowed disabled:border-transparent disabled:bg-muted disabled:text-muted-foreground disabled:opacity-60"
                      >
                        {isAdded(suggestion) ? "已添加" : "添加"}
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
