"use client";

import { useState } from "react";
import { Icon } from "./icons";

export function RefreshButton() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const refresh = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/refresh", { method: "POST" });
      const data = await response.json();
      if (!response.ok || !data.ok) {
        throw new Error(data.error ?? "刷新失败");
      }
      window.location.reload();
    } catch (err) {
      setError(err instanceof Error ? err.message : "刷新失败");
      setLoading(false);
    }
  };

  return (
    <span className="inline-flex items-center gap-2">
      <button
        type="button"
        className="control"
        onClick={refresh}
        disabled={loading}
        title="按现有信息源刷新（使用本地封面缓存）"
      >
        <Icon
          name="refresh"
          className={loading ? "h-[18px] w-[18px] animate-spin" : "h-[18px] w-[18px]"}
        />
        <span>{loading ? "刷新中…" : "刷新"}</span>
      </button>
      {error ? (
        <span className="max-w-[180px] truncate text-xs text-primary" title={error}>
          {error}
        </span>
      ) : null}
    </span>
  );
}
