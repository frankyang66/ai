"use client";

import { useMemo, useState, useSyncExternalStore } from "react";
import {
  getOverrides,
  getServerOverrides,
  mergeSources,
  subscribeOverrides,
  type ManagedSource,
} from "@/lib/source-overrides";
import { Icon } from "./icons";
import { Modal } from "./modal";
import { SourcesAssistant } from "./sources-assistant";

export function SearchDsButton({
  query,
  sources,
}: {
  query: string;
  sources: ManagedSource[];
}) {
  const [open, setOpen] = useState(false);
  const overrides = useSyncExternalStore(
    subscribeOverrides,
    getOverrides,
    getServerOverrides,
  );
  const merged = useMemo(
    () => mergeSources(sources, overrides),
    [sources, overrides],
  );

  if (!query.trim()) return null;

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-card px-3 py-1.5 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
      >
        <Icon name="sparkles" className="h-3.5 w-3.5" />
        校内没有？让 DS 全网找
      </button>

      {open ? (
        <Modal title="DS 全网找" wide onClose={() => setOpen(false)}>
          <SourcesAssistant sources={merged} initialPrompt={query} />
        </Modal>
      ) : null}
    </>
  );
}
