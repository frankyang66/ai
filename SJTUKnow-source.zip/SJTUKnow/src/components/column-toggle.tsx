"use client";

import { useState } from "react";
import { Icon } from "./icons";

export function ColumnToggle() {
  const [columns, setColumns] = useState<2 | 6>(6);

  const choose = (next: 2 | 6) => {
    setColumns(next);
    document.documentElement.dataset.columns = String(next);
  };

  return (
    <div className="flex items-center gap-1 rounded-xl border border-border bg-card p-0.5">
      <button
        type="button"
        onClick={() => choose(6)}
        aria-pressed={columns === 6}
        className={`inline-flex h-8 items-center gap-1.5 rounded-lg px-2.5 text-xs font-semibold transition-colors ${
          columns === 6
            ? "bg-accent text-primary"
            : "text-muted-foreground hover:text-primary"
        }`}
        title="每行 6 列"
      >
        <Icon name="columns" className="h-4 w-4" />6 列
      </button>
      <button
        type="button"
        onClick={() => choose(2)}
        aria-pressed={columns === 2}
        className={`inline-flex h-8 items-center gap-1.5 rounded-lg px-2.5 text-xs font-semibold transition-colors ${
          columns === 2
            ? "bg-accent text-primary"
            : "text-muted-foreground hover:text-primary"
        }`}
        title="每行 2 列"
      >
        <Icon name="grid2" className="h-4 w-4" />2 列
      </button>
    </div>
  );
}
