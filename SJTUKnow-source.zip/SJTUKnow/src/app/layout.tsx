import type { Metadata, Viewport } from "next";
import "./globals.css";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { SortListener } from "@/components/sort-listener";
import { getSourcesWithCounts } from "@/lib/data";

export const viewport: Viewport = {
  themeColor: "#f7f8fa",
};

export const metadata: Metadata = {
  title: {
    default: "「交大知道」 SJTU Know",
    template: "%s · 交大知道",
  },
  description:
    "聚合上海交通大学各院系、部门与校园媒体公开发布的活动、讲座与通知。",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  const sources = getSourcesWithCounts();

  return (
    <html lang="zh-CN" className="h-full antialiased">
      <body className="flex min-h-full flex-col">
        <SiteHeader sources={sources} />
        <SortListener />
        <main className="flex-1">{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
