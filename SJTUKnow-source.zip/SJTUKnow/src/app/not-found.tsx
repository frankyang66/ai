import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex w-full max-w-[1480px] flex-col items-center px-7 py-24 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-xl border border-border bg-card font-serif text-2xl text-muted-foreground">
        知
      </div>
      <h1 className="mt-5 text-2xl font-bold text-foreground">页面不存在</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        这条信息可能已被移除，或链接有误。
      </p>
      <Link
        href="/"
        className="mt-6 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-accent-foreground"
      >
        返回首页
      </Link>
    </div>
  );
}
