import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { CategoryNav } from "@/components/category-nav";
import { MatchedSources } from "@/components/matched-sources";
import { NoticeCard } from "@/components/notice-card";
import { NoticePagination, paginateNotices } from "@/components/notice-pagination";
import { SearchBar } from "@/components/search-bar";
import { SearchDsButton } from "@/components/search-ds";
import { getSourcesWithCounts, searchNotices } from "@/lib/data";
import type { Source } from "@/lib/types";

export const metadata: Metadata = { title: "搜索" };

type SourceItem = Source & { count: number };

async function SearchTop({
  searchParams,
  sources,
}: {
  searchParams: Promise<{ q?: string; page?: string }>;
  sources: SourceItem[];
}) {
  const { q = "" } = await searchParams;
  const keyword = q.trim();

  return (
    <div className="max-w-xl">
      <SearchBar defaultValue={q} autoFocus />
      <div className="mt-2 flex flex-wrap items-center gap-2">
        <p className="text-xs leading-relaxed text-muted-foreground">
          先搜已收录的交大公开信息；没有的话可以让 DS 去全网找。
        </p>
        <SearchDsButton query={keyword} sources={sources} />
      </div>
    </div>
  );
}

async function SearchResults({
  searchParams,
  sources,
}: {
  searchParams: Promise<{ q?: string; page?: string }>;
  sources: SourceItem[];
}) {
  const { q = "", page } = await searchParams;
  const keyword = q.trim();
  const results = keyword ? searchNotices(keyword) : [];

  const { items, current, totalPages } = paginateNotices(results, page);

  if (!keyword) {
    return (
      <p className="mt-8 text-sm text-muted-foreground">
        输入关键词，搜索标题、摘要与信息源名称。
      </p>
    );
  }

  return (
    <div className="mt-2">
      <MatchedSources query={keyword} sources={sources} />
      <div className="feed-toolbar mt-5">
        <h2 className="feed-title">
          搜索结果
          <span className="feed-count">{results.length}</span>
        </h2>
        <span className="ml-auto text-xs text-muted-foreground">
          「{keyword}」
        </span>
      </div>
      {results.length > 0 ? (
        <>
          <div className="waterfall-grid">
            {items.map((notice) => (
              <NoticeCard key={notice.id} notice={notice} />
            ))}
          </div>
          <NoticePagination
            current={current}
            totalPages={totalPages}
            pageHref={(nextPage) => {
              const params = new URLSearchParams({ q: keyword });
              if (nextPage > 1) params.set("page", String(nextPage));
              return `/search?${params}`;
            }}
          />
        </>
      ) : (
        <div className="rounded-2xl border border-border bg-card px-6 py-16 text-center">
          <p className="text-lg font-semibold text-foreground">
            校内暂未收录相关内容
          </p>
          <p className="mt-2 text-sm text-muted-foreground">
            可以点上方「让 DS 全网找」，或换个关键词试试。
          </p>
          <Link
            href="/sources"
            className="mt-5 inline-block text-sm font-semibold text-primary underline-offset-4 hover:underline"
          >
            查看信息来源 →
          </Link>
        </div>
      )}
    </div>
  );
}

function SearchSkeleton() {
  return (
    <div className="mt-6 waterfall-grid">
      {Array.from({ length: 6 }, (_, index) => (
        <div
          key={index}
          className="h-64 animate-pulse rounded-xl border border-border bg-card/70"
        />
      ))}
    </div>
  );
}

export default function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; page?: string }>;
}) {
  const sources = getSourcesWithCounts();

  return (
    <div className="mx-auto w-full max-w-[1480px] px-7 pb-4 pt-3">
      <CategoryNav />
      <div className="board-toolbar mt-1">
        <h1 className="feed-title">搜索</h1>
      </div>
      <Suspense
        fallback={
          <div className="h-[42px] max-w-xl animate-pulse rounded-xl border border-border bg-card/70" />
        }
      >
        <SearchTop searchParams={searchParams} sources={sources} />
      </Suspense>
      <Suspense fallback={<SearchSkeleton />}>
        <SearchResults searchParams={searchParams} sources={sources} />
      </Suspense>
    </div>
  );
}
