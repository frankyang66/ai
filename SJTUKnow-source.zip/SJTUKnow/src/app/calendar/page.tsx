import type { Metadata } from "next";
import Link from "next/link";
import { CategoryNav } from "@/components/category-nav";
import { EmptyState } from "@/components/empty-state";
import { Icon } from "@/components/icons";
import { NoticeCard } from "@/components/notice-card";
import { getAllNotices } from "@/lib/data";
import { formatAbsolute } from "@/lib/format";

export const metadata: Metadata = { title: "活动日历" };

export default function CalendarPage() {
  const notices = getAllNotices();
  const events = notices
    .filter((notice) => notice.event_start)
    .sort(
      (a, b) =>
        new Date(a.event_start as string).getTime() -
        new Date(b.event_start as string).getTime(),
    );
  const activityFallback = notices
    .filter((notice) => notice.intent === "activity")
    .slice(0, 8);

  const groups = new Map<string, typeof events>();
  for (const event of events.slice(0, 60)) {
    const key = (event.event_start as string).slice(0, 10);
    const list = groups.get(key) ?? [];
    list.push(event);
    groups.set(key, list);
  }

  return (
    <div className="mx-auto w-full max-w-[1480px] px-7 pb-4 pt-3">
      <CategoryNav />

      <div className="feed-toolbar mt-1">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-border bg-card text-primary">
          <Icon name="calendar" className="h-[18px] w-[18px]" />
        </span>
        <h1 className="feed-title">活动日历</h1>
        <Link
          href="/"
          className="ml-auto inline-flex items-center gap-1.5 rounded-xl border border-border bg-card px-3.5 py-2 text-xs font-semibold text-muted-foreground transition-colors hover:border-input hover:text-primary"
        >
          <Icon name="chevron-left" className="h-4 w-4" />
          返回首页
        </Link>
      </div>

      {events.length === 0 ? (
        <div className="mt-1">
          <div className="rounded-2xl border border-border bg-card px-6 py-10 text-center">
            <p className="text-lg font-semibold text-foreground">
              暂无活动日程
            </p>
          </div>
          {activityFallback.length > 0 ? (
            <>
              <div className="feed-toolbar">
                <h2 className="feed-title">
                  最新活动
                  <span className="feed-count">{activityFallback.length}</span>
                </h2>
              </div>
              <div className="waterfall-grid">
                {activityFallback.map((notice) => (
                  <NoticeCard key={notice.id} notice={notice} />
                ))}
              </div>
            </>
          ) : (
            <div className="mt-4">
              <EmptyState title="还没有可展示的活动" />
            </div>
          )}
        </div>
      ) : (
        <div className="mt-2 space-y-5">
          {Array.from(groups.entries()).map(([date, items]) => (
            <section
              key={date}
              className="rounded-2xl border border-border bg-card px-5 py-4"
            >
              <h2 className="mb-3 text-sm font-bold text-foreground">
                {formatAbsolute(`${date}T00:00:00+08:00`)}
                <span className="ml-2 text-xs font-medium text-muted-foreground">
                  {items.length} 场
                </span>
              </h2>
              <ul className="divide-y divide-border">
                {items.map((item) => (
                  <li key={item.id}>
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex flex-wrap items-center gap-x-4 gap-y-1 py-2.5 text-sm transition-colors hover:text-primary"
                    >
                      <time className="w-14 shrink-0 text-xs font-semibold text-muted-foreground">
                        {(item.event_start as string).slice(11, 16)}
                      </time>
                      <span className="min-w-0 flex-1 truncate font-medium">
                        {item.title}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {item.location ?? item.source_name}
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
