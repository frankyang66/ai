import { spawn } from "node:child_process";
import { NextResponse } from "next/server";

export const maxDuration = 600;

let running = false;

export async function POST() {
  if (running) {
    return NextResponse.json(
      { ok: false, error: "正在刷新，请稍候。" },
      { status: 409 },
    );
  }

  running = true;

  try {
    await new Promise<void>((resolve, reject) => {
      const child = spawn(process.execPath, ["scripts/scrape.mjs"], {
        cwd: process.cwd(),
        env: {
          ...process.env,
          SKIP_ARTICLE_COVERS: "1",
          WECHAT_FETCH_LIMIT: process.env.WECHAT_FETCH_LIMIT ?? "20",
          WECHAT_QUEUE_LIMIT: process.env.WECHAT_QUEUE_LIMIT ?? "10",
        },
      });

      let output = "";
      child.stdout.on("data", (chunk) => {
        output += String(chunk);
      });
      child.stderr.on("data", (chunk) => {
        output += String(chunk);
      });

      const timer = setTimeout(() => {
        child.kill("SIGKILL");
        reject(new Error("刷新超时"));
      }, 9 * 60 * 1000);

      child.on("close", (code) => {
        clearTimeout(timer);
        if (code === 0) {
          resolve();
        } else {
          reject(
            new Error(
              output.trim().split("\n").slice(-3).join(" ") ||
                `刷新脚本退出码 ${code}`,
            ),
          );
        }
      });
      child.on("error", (error) => {
        clearTimeout(timer);
        reject(error);
      });
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "刷新失败",
      },
      { status: 500 },
    );
  } finally {
    running = false;
  }
}
