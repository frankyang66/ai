import { NextResponse } from "next/server";

interface VerifyResult {
  ok: boolean;
  status: number;
  finalUrl: string;
  title: string;
  error?: string;
}

const cache = new Map<string, { at: number; result: VerifyResult }>();
const TTL = 10 * 60 * 1000;

const USER_AGENT =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

export async function GET(request: Request) {
  const target = new URL(request.url).searchParams.get("url") ?? "";
  if (!/^https?:\/\//i.test(target)) {
    return NextResponse.json(
      { ok: false, status: 0, finalUrl: target, title: "", error: "invalid" },
      { status: 400 },
    );
  }

  const cached = cache.get(target);
  if (cached && Date.now() - cached.at < TTL) {
    return NextResponse.json(cached.result);
  }

  let result: VerifyResult = {
    ok: false,
    status: 0,
    finalUrl: target,
    title: "",
    error: "fetch_failed",
  };

  for (let attempt = 0; attempt < 2; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000 + attempt * 5000);
    try {
      const response = await fetch(target, {
        signal: controller.signal,
        redirect: "follow",
        headers: {
          "User-Agent": USER_AGENT,
          Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
          "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        },
      });
      const html = response.ok ? (await response.text()).slice(0, 30000) : "";
      const title =
        /<title[^>]*>([\s\S]*?)<\/title>/i
          .exec(html)?.[1]
          ?.replace(/\s+/g, " ")
          .trim() ?? "";
      result = {
        ok: response.ok,
        status: response.status,
        finalUrl: response.url,
        title,
      };
      break;
    } catch {
      result = {
        ok: false,
        status: 0,
        finalUrl: target,
        title: "",
        error: "fetch_failed",
      };
    } finally {
      clearTimeout(timer);
    }
  }

  // Only cache successes; transient failures should be retried next time.
  if (result.ok) {
    cache.set(target, { at: Date.now(), result });
  }
  return NextResponse.json(result);
}
