import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";

const MESSAGES_PATH = path.join(process.cwd(), "src", "data", "messages.json");

interface Message {
  id: string;
  nickname: string;
  content: string;
  created_at: string;
  status: string;
  reply?: string | null;
}

async function readMessages(): Promise<Message[]> {
  try {
    const raw = await fs.readFile(MESSAGES_PATH, "utf8");
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

export async function GET() {
  const messages = await readMessages();
  return NextResponse.json({ messages: messages.slice().reverse() });
}

export async function POST(request: Request) {
  let body: { nickname?: unknown; content?: unknown } | null = null;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "请求格式有误。" }, { status: 400 });
  }

  const nickname =
    String(body?.nickname ?? "").trim().slice(0, 40) || "匿名同学";
  const content = String(body?.content ?? "").trim();

  if (!content || content.length > 800) {
    return NextResponse.json(
      { error: "留言内容需在 1-800 字之间。" },
      { status: 400 },
    );
  }

  const messages = await readMessages();
  const message: Message = {
    id: crypto.randomUUID(),
    nickname,
    content,
    created_at: new Date().toISOString(),
    status: "待处理",
    reply: null,
  };
  messages.push(message);
  await fs.writeFile(MESSAGES_PATH, `${JSON.stringify(messages, null, 2)}\n`);

  return NextResponse.json({ message });
}
