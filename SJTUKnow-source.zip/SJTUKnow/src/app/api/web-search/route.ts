import * as cheerio from "cheerio";
import { NextResponse } from "next/server";

interface WebResult {
  title: string;
  url: string;
  snippet: string;
}

const cache = new Map<string, { at: number; results: WebResult[] }>();
const TTL = 10 * 60 * 1000;
const USER_AGENT =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

function normalizeBingUrl(url: string): string {
  try {
    const parsed = new URL(url);
    if (
      parsed.hostname.endsWith("bing.com") &&
      parsed.pathname.startsWith("/ck/a")
    ) {
      const encoded = parsed.searchParams.get("u");
      if (encoded?.startsWith("a1")) {
        try {
          return Buffer.from(encoded.slice(2), "base64url").toString("utf8");
        } catch {
          return url;
        }
      }
    }
    return url;
  } catch {
    return url;
  }
}

async function searchBing(query: string): Promise<WebResult[]> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(
      `https://cn.bing.com/search?q=${encodeURIComponent(
        query,
      )}&setlang=zh-cn&count=10`,
      {
        signal: controller.signal,
        redirect: "follow",
        headers: {
          "User-Agent": USER_AGENT,
          Accept:
            "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        },
      },
    );
    if (!response.ok) return [];
    const html = await response.text();
    const $ = cheerio.load(html);
    const results: WebResult[] = [];
    const seen = new Set<string>();

    $("li.b_algo").each((_, element) => {
      const $item = $(element);
      const $link = $item.find("h2 a").first();
      const url = normalizeBingUrl($link.attr("href") ?? "");
      const title = $link.text().trim();
      const snippet = $item.find("p").first().text().replace(/\s+/g, " ").trim();

      if (!title || !/^https?:\/\//i.test(url)) return;
      if (url.includes("bing.com") || seen.has(url)) return;
      seen.add(url);
      results.push({ title, url, snippet: snippet.slice(0, 220) });
    });

    return results.slice(0, 8);
  } catch {
    return [];
  } finally {
    clearTimeout(timer);
  }
}

export async function GET(request: Request) {
  const query = (new URL(request.url).searchParams.get("q") ?? "")
    .trim()
    .slice(0, 200);
  if (!query) {
    return NextResponse.json({ results: [] });
  }

  const cached = cache.get(query);
  if (cached && Date.now() - cached.at < TTL) {
    return NextResponse.json({ results: cached.results });
  }

  const results = await searchBing(query);
  // Never cache empty results: they are often caused by transient rate limits.
  if (results.length > 0) {
    cache.set(query, { at: Date.now(), results });
  }
  return NextResponse.json({ results });
}
