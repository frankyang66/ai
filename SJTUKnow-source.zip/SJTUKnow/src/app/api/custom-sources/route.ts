import fs from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";

const FILE = path.join(process.cwd(), "src", "data", "custom-sources.json");

interface StoredSource {
  id: string;
  name: string;
  type: "official_site" | "wechat";
  url: string;
}

async function read(): Promise<StoredSource[]> {
  try {
    const raw = await fs.readFile(FILE, "utf8");
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function sanitize(input: unknown): StoredSource[] {
  if (!Array.isArray(input)) return [];
  const seen = new Set<string>();
  const result: StoredSource[] = [];
  for (const item of input.slice(0, 100)) {
    const record = item as Record<string, unknown>;
    const id = String(record.id ?? "").trim();
    const name = String(record.name ?? "").trim().slice(0, 100);
    const url = String(record.url ?? "").trim();
    const type = record.type === "wechat" ? "wechat" : "official_site";
    if (!id || !name || !/^https?:\/\//i.test(url)) continue;
    if (seen.has(id)) continue;
    seen.add(id);
    result.push({ id, name, type, url });
  }
  return result;
}

export async function GET() {
  return NextResponse.json({ sources: await read() });
}

export async function POST(request: Request) {
  let body: unknown = null;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "请求格式有误。" }, { status: 400 });
  }

  const payload = body as { source?: unknown; sources?: unknown };

  // Single-source add/update keeps other clients' entries.
  if (payload.source) {
    const [source] = sanitize([payload.source]);
    if (!source) {
      return NextResponse.json({ error: "来源信息不完整。" }, { status: 400 });
    }
    const existing = await read();
    const merged = [...existing.filter((item) => item.id !== source.id), source];
    await fs.writeFile(FILE, `${JSON.stringify(merged, null, 2)}\n`);
    return NextResponse.json({ ok: true, sources: merged });
  }

  const sources = sanitize(payload.sources);
  await fs.writeFile(FILE, `${JSON.stringify(sources, null, 2)}\n`);
  return NextResponse.json({ ok: true, sources });
}

export async function DELETE(request: Request) {
  const id = new URL(request.url).searchParams.get("id") ?? "";
  if (!id) {
    return NextResponse.json({ error: "缺少来源 ID。" }, { status: 400 });
  }
  const existing = await read();
  const next = existing.filter((item) => item.id !== id);
  await fs.writeFile(FILE, `${JSON.stringify(next, null, 2)}\n`);
  return NextResponse.json({ ok: true, sources: next });
}
