import type { Metadata } from "next";
import { SourcesPanel } from "@/components/sources-panel";
import { getSourcesWithCounts } from "@/lib/data";

export const metadata: Metadata = { title: "信息来源" };

export default function SourcesPage() {
  const sources = getSourcesWithCounts();

  return (
    <div className="mx-auto w-full max-w-2xl px-7 py-6">
      <div className="rounded-2xl border border-border bg-card px-5 py-4">
        <h1 className="text-lg font-bold text-foreground">信息来源</h1>
        <div className="mt-4">
          <SourcesPanel sources={sources} />
        </div>
      </div>
    </div>
  );
}
