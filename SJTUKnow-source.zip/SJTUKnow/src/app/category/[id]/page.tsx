import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { CategoryNav } from "@/components/category-nav";
import { ToolbarSelect } from "@/components/toolbar-select";
import { EmptyState } from "@/components/empty-state";
import { Icon } from "@/components/icons";
import { NoticeCard } from "@/components/notice-card";
import {
  NOTICE_PAGE_SIZE,
  NoticePagination,
  paginateNotices,
} from "@/components/notice-pagination";
import {
  CATEGORY_MAP,
  VISIBLE_CATEGORY_IDS,
  isVisibleCategory,
} from "@/lib/categories";
import { getNoticesByCategory } from "@/lib/data";
import type { CategoryId } from "@/lib/types";

export function generateStaticParams() {
  return VISIBLE_CATEGORY_IDS.map((id) => ({ id }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const category = CATEGORY_MAP[id as CategoryId];
  return { title: category ? category.label : "分类" };
}

async function CategoryResults({
  categoryId,
  searchParams,
}: {
  categoryId: CategoryId;
  searchParams: Promise<{ page?: string; sort?: string }>;
}) {
  const { page: pageParam, sort } = await searchParams;
  const notices = getNoticesByCategory(categoryId, sort === "cover" ? "cover" : undefined);
  const { items, current, totalPages } = paginateNotices(notices, pageParam);
  const basePath = `/category/${categoryId}`;

  if (notices.length === 0) {
    return <EmptyState title="这个分类还没有内容" />;
  }

  return (
    <>
      <div className="waterfall-grid">
        {items.map((notice) => (
          <NoticeCard key={notice.id} notice={notice} />
        ))}
      </div>
      <NoticePagination
        current={current}
        totalPages={totalPages}
        pageHref={(page) => {
          const params = new URLSearchParams();
          if (sort === "cover") params.set("sort", "cover");
          if (page > 1) params.set("page", String(page));
          const query = params.toString();
          return query ? `${basePath}?${query}` : basePath;
        }}
      />
    </>
  );
}

function ResultsSkeleton() {
  return (
    <div className="waterfall-grid">
      {Array.from({ length: NOTICE_PAGE_SIZE }, (_, index) => (
        <div
          key={index}
          className="h-64 animate-pulse rounded-xl border border-border bg-card/70"
        />
      ))}
    </div>
  );
}

async function CategoryFeed({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ page?: string; sort?: string }>;
}) {
  const { id } = await params;
  const category = CATEGORY_MAP[id as CategoryId];
  if (!category || !isVisibleCategory(category.id)) notFound();

  const count = getNoticesByCategory(category.id).length;
  const sort = (await searchParams).sort === "cover" ? "cover" : "time";
  const basePath = `/category/${category.id}`;

  return (
    <div className="mx-auto w-full max-w-[1480px] px-7 pb-4 pt-3">
      <CategoryNav activeId={category.id} />

      <div className="board-toolbar mt-1">
        <Link
          href="/"
          className="category-back"
          aria-label="返回全部"
        >
          <Icon name="chevron-left" className="h-4 w-4" />
        </Link>
        <h1 className="feed-title">
          {category.label}
          <span className="feed-count">{count}</span>
        </h1>
        <div className="board-tools">
          <ToolbarSelect
            key={sort ?? "time"}
            icon="clock"
            defaultValue={sort}
            target="sort"
            options={[
              { value: "time", label: "时间排序", href: sort === "cover" ? basePath : undefined },
              { value: "source", label: "来源排序" },
              { value: "cover", label: "有图优先", href: `${basePath}?sort=cover` },
            ]}
          />
          <ToolbarSelect
            icon="sliders"
            options={[
              { value: "all", label: "全部板块", href: "/" },
              { value: "arts", label: "文体", href: "/category/arts" },
              { value: "clubs", label: "社团", href: "/category/clubs" },
              { value: "lectures", label: "讲座", href: "/category/lectures" },
              { value: "careers", label: "就业", href: "/category/careers" },
              { value: "services", label: "服务", href: "/category/services" },
            ]}
          />
          <ToolbarSelect
            icon="columns"
            defaultValue="standard"
            target="columns"
            options={[
              { value: "standard", label: "标准布局" },
              { value: "2", label: "2 列" },
            ]}
          />
        </div>
      </div>

      <div className="mt-1">
        <Suspense fallback={<ResultsSkeleton />}>
          <CategoryResults
            categoryId={category.id}
            searchParams={searchParams}
          />
        </Suspense>
      </div>
    </div>
  );
}


export default function CategoryPage(props: Parameters<typeof CategoryFeed>[0]) {
  return (
    <Suspense fallback={<ResultsSkeleton />}>
      <CategoryFeed {...props} />
    </Suspense>
  );
}
