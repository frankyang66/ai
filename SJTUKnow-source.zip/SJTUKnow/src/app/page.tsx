import { Suspense, type CSSProperties } from "react";
import Link from "next/link";
import { CategoryNav } from "@/components/category-nav";
import { ToolbarSelect } from "@/components/toolbar-select";
import { EmptyState } from "@/components/empty-state";
import { Icon, CategoryIcon } from "@/components/icons";
import { NoticeCard } from "@/components/notice-card";
import { NOTICE_PAGE_SIZE } from "@/components/notice-pagination";
import { RefreshButton } from "@/components/refresh-button";
import {
  ACTIVITY_CATEGORIES,
  NOTICE_CATEGORIES,
} from "@/lib/categories";
import {
  getAllNotices,
  getCategoriesWithCounts,
  getNoticesByCategory,
  getStats,
} from "@/lib/data";

async function HomeFeed({
  searchParams,
}: {
  searchParams: Promise<{ sort?: string }>;
}) {
  const sort = (await searchParams).sort === "cover" ? "cover" : undefined;
  const suffix = sort ? "?sort=cover" : "";
  const stats = getStats();
  const notices = getAllNotices();
  const counts = new Map(
    getCategoriesWithCounts().map((category) => [category.id, category.count]),
  );
  const sections = [...ACTIVITY_CATEGORIES, ...NOTICE_CATEGORIES].filter(
    (category) => (counts.get(category.id) ?? 0) > 0,
  );

  return (
    <>
      <div className="board-toolbar mt-1">
        <h2 className="feed-title">
          全部
          <span className="feed-count">
            {stats.noticeCount}
            <span className="sr-only">条通知</span>
          </span>
        </h2>
        <div className="board-tools">
          <ToolbarSelect
            key={sort ?? "time"}
            icon="clock"
            defaultValue={sort ?? "time"}
            target="sort"
            options={[
              { value: "time", label: "时间排序", href: sort ? "/" : undefined },
              { value: "source", label: "来源排序" },
              { value: "cover", label: "有图优先", href: "/?sort=cover" },
            ]}
          />
          <ToolbarSelect
            icon="sliders"
            options={[
              { value: "all", label: "全部板块", href: "/" },
              { value: "arts", label: "文体", href: "/category/arts" },
              { value: "clubs", label: "社团", href: "/category/clubs" },
              { value: "lectures", label: "讲座", href: "/category/lectures" },
              { value: "careers", label: "就业", href: "/category/careers" },
              { value: "services", label: "服务", href: "/category/services" },
            ]}
          />
          <ToolbarSelect
            icon="columns"
            defaultValue="standard"
            target="columns"
            options={[
              { value: "standard", label: "标准布局" },
              { value: "2", label: "2 列" },
            ]}
          />
          <RefreshButton />
        </div>
      </div>
      <p className="sr-only">
        找到 {stats.noticeCount} 条通知，可进入分类查看更多
      </p>

      {notices.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="mt-1">
          {sections.map((category) => {
            const items = getNoticesByCategory(category.id, sort);
            const count = counts.get(category.id) ?? 0;

            return (
              <section
                key={category.id}
                className="notice-section"
                style={{ "--tone": category.color } as CSSProperties}
              >
                <div className="section-head">
                  <CategoryIcon id={category.id} />
                  <h3 className="section-title">{category.label}</h3>
                  <span className="section-count">{count}条</span>
                  <Link
                    href={`/category/${category.id}${suffix}`}
                    className="section-more"
                  >
                    查看更多
                    <Icon name="arrow-right" className="h-4 w-4" />
                  </Link>
                </div>
                <div className="waterfall-grid">
                  {items.slice(0, NOTICE_PAGE_SIZE).map((notice) => (
                    <NoticeCard key={notice.id} notice={notice} />
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}


export default function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ sort?: string }>;
}) {
  return (
    <div className="mx-auto w-full max-w-[1480px] px-7 pb-4 pt-3">
      <CategoryNav />
      <Suspense fallback={<div className="mt-3 h-64 animate-pulse rounded-xl bg-card" />}>
        <HomeFeed searchParams={searchParams} />
      </Suspense>
    </div>
  );
}
