"use client";

export interface CustomBoard {
  id: string;
  label: string;
  color: string;
}

export interface BoardState {
  hidden: string[];
  custom: CustomBoard[];
  assignments: Record<string, string[]>;
}

const STORAGE_KEY = "sjtuknow:boards";
const DEFAULT_HIDDEN = [
  "clubs",
  "growth",
  "exchange",
  "campus",
  "research",
  "departments",
  "life",
  "academics",
  "scholarships",
];
const EMPTY: BoardState = { hidden: [], custom: [], assignments: {} };

let cached: BoardState | null = null;
const listeners = new Set<() => void>();

function read(): BoardState {
  if (typeof window === "undefined") return EMPTY;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return { hidden: DEFAULT_HIDDEN, custom: [], assignments: {} };
    }
    const parsed = JSON.parse(raw) as Partial<BoardState>;
    return {
      hidden: Array.isArray(parsed.hidden) ? parsed.hidden : [],
      custom: Array.isArray(parsed.custom) ? parsed.custom : [],
      assignments:
        parsed.assignments && typeof parsed.assignments === "object"
          ? parsed.assignments
          : {},
    };
  } catch {
    return EMPTY;
  }
}

export function getBoardState(): BoardState {
  if (typeof window === "undefined") return EMPTY;
  if (cached === null) cached = read();
  return cached;
}

export function getServerBoardState(): BoardState {
  return EMPTY;
}

export function subscribeBoards(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function persist(next: BoardState) {
  cached = next;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Ignore unavailable storage.
  }
  for (const listener of listeners) listener();
}

export function addBoard(label: string, color: string): CustomBoard {
  const current = getBoardState();
  const id = `board_${Date.now().toString(36)}`;
  const board: CustomBoard = {
    id,
    label: label.trim().slice(0, 20),
    color: /^#[0-9a-f]{6}$/i.test(color) ? color : "#a51c30",
  };
  persist({ ...current, custom: [...current.custom, board] });
  return board;
}

export function removeBoard(id: string) {
  const current = getBoardState();
  const assignments: Record<string, string[]> = {};
  for (const [sourceId, boardIds] of Object.entries(current.assignments)) {
    assignments[sourceId] = boardIds.filter((boardId) => boardId !== id);
  }

  if (id.startsWith("board_")) {
    persist({
      ...current,
      custom: current.custom.filter((board) => board.id !== id),
      assignments,
    });
    return;
  }

  if (current.hidden.includes(id)) return;
  persist({
    ...current,
    hidden: [...current.hidden, id],
    assignments,
  });
}

export function restoreBoard(id: string) {
  const current = getBoardState();
  persist({
    ...current,
    hidden: current.hidden.filter((boardId) => boardId !== id),
  });
}

export function assignSource(sourceId: string, boardIds: string[]) {
  const current = getBoardState();
  persist({
    ...current,
    assignments: {
      ...current.assignments,
      [sourceId]: Array.from(new Set(boardIds)),
    },
  });
}
