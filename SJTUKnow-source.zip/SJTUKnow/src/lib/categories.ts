import type { Category, CategoryId } from "./types";

export const CATEGORIES: Category[] = [
  {
    id: "arts",
    label: "文体",
    group: "activity",
    description: "演出、展览、体育与文艺活动",
    color: "#b3455f",
  },
  {
    id: "clubs",
    label: "社团",
    group: "activity",
    description: "社团招新、志愿公益与社会实践",
    color: "#2f7d6d",
  },
  {
    id: "lectures",
    label: "讲座",
    group: "activity",
    description: "学术讲座、论坛与研讨会",
    color: "#6d4aa8",
  },
  {
    id: "growth",
    label: "学习",
    group: "activity",
    description: "工作坊、培训与学业发展",
    color: "#4f7a3a",
  },
  {
    id: "careers",
    label: "就业",
    group: "activity",
    description: "招聘宣讲、实习与职业发展",
    color: "#a86b2d",
  },
  {
    id: "exchange",
    label: "留学",
    group: "activity",
    description: "访学、交换、留学与国际项目",
    color: "#356fa8",
  },
  {
    id: "campus",
    label: "校园",
    group: "notice",
    description: "校级通知与校园公告",
    color: "#4a6274",
  },
  {
    id: "research",
    label: "科研",
    group: "notice",
    description: "科研动态、项目申报与学术信息",
    color: "#4c5fa8",
  },
  {
    id: "departments",
    label: "院系",
    group: "notice",
    description: "各学院与院系发布的通知",
    color: "#8a5a3b",
  },
  {
    id: "life",
    label: "生活",
    group: "notice",
    description: "后勤、餐饮、场馆与园区生活",
    color: "#6b7a3a",
  },
  {
    id: "academics",
    label: "学业",
    group: "notice",
    description: "选课、考试、培养与学籍",
    color: "#2f6f7d",
  },
  {
    id: "scholarships",
    label: "奖学金",
    group: "notice",
    description: "奖学金、助学金与评奖评优",
    color: "#9a7b2d",
  },
  {
    id: "services",
    label: "服务",
    group: "notice",
    description: "办事指南与校园服务",
    color: "#6b635e",
  },
];

export const CATEGORY_MAP: Record<CategoryId, Category> = Object.fromEntries(
  CATEGORIES.map((category) => [category.id, category]),
) as Record<CategoryId, Category>;

export const VISIBLE_CATEGORY_IDS: CategoryId[] = [
  "lectures",
  "careers",
  "arts",
  "services",
];

const VISIBLE_SET = new Set<CategoryId>(VISIBLE_CATEGORY_IDS);

export function isVisibleCategory(id: CategoryId): boolean {
  return VISIBLE_SET.has(id);
}

const VISIBLE_ORDER = new Map<CategoryId, number>(
  VISIBLE_CATEGORY_IDS.map((id, index) => [id, index]),
);

export const ACTIVITY_CATEGORIES = CATEGORIES.filter(
  (category) => category.group === "activity" && VISIBLE_SET.has(category.id),
).sort(
  (a, b) =>
    (VISIBLE_ORDER.get(a.id) ?? 99) - (VISIBLE_ORDER.get(b.id) ?? 99),
);

export const NOTICE_CATEGORIES = CATEGORIES.filter(
  (category) => category.group === "notice" && VISIBLE_SET.has(category.id),
).sort(
  (a, b) =>
    (VISIBLE_ORDER.get(a.id) ?? 99) - (VISIBLE_ORDER.get(b.id) ?? 99),
);
