"use client";

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  at: number;
}

const STORAGE_KEY = "sjtuknow:ds-history";
const EMPTY: ChatMessage[] = [];
let cached: ChatMessage[] | null = null;
const listeners = new Set<() => void>();

function read(): ChatMessage[] {
  if (typeof window === "undefined") return EMPTY;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return EMPTY;
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return EMPTY;
    return parsed
      .filter(
        (item) =>
          item &&
          (item.role === "user" || item.role === "assistant") &&
          typeof item.content === "string",
      )
      .slice(-16);
  } catch {
    return EMPTY;
  }
}

export function getHistory(): ChatMessage[] {
  if (typeof window === "undefined") return EMPTY;
  if (cached === null) cached = read();
  return cached;
}

export function getServerHistory(): ChatMessage[] {
  return EMPTY;
}

export function subscribeHistory(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function persist(next: ChatMessage[]) {
  cached = next;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Storage may be unavailable; keep the in-memory copy.
  }
  for (const listener of listeners) listener();
}

export function appendTurn(message: Omit<ChatMessage, "at">) {
  const current = getHistory();
  persist([...current, { ...message, at: Date.now() }].slice(-16));
}

export function clearHistory() {
  persist([]);
}
