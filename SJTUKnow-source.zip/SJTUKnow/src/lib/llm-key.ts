"use client";

const STORAGE_KEY = "sjtuknow:deepseek-key";

let cached: string | null = null;
const listeners = new Set<() => void>();

function emit() {
  for (const listener of listeners) listener();
}

export function getApiKey(): string {
  if (typeof window === "undefined") return "";
  if (cached === null) {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      cached = stored ?? "";
    } catch {
      cached = "";
    }
  }
  return cached;
}

export function getServerApiKey(): string {
  return "";
}

export function subscribeApiKey(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function saveApiKey(value: string) {
  cached = value;
  try {
    window.localStorage.setItem(STORAGE_KEY, value);
  } catch {
    // Storage may be unavailable; keep the in-memory value.
  }
  emit();
}

export function clearApiKey() {
  saveApiKey("");
}
