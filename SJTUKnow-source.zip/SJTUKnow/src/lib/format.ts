const monthDay = new Intl.DateTimeFormat("zh-CN", {
  month: "long",
  day: "numeric",
  timeZone: "Asia/Shanghai",
});

const monthDayTime = new Intl.DateTimeFormat("zh-CN", {
  month: "long",
  day: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hour12: false,
  timeZone: "Asia/Shanghai",
});

function toDate(iso: string): Date {
  return new Date(iso);
}

export function formatAbsolute(iso: string): string {
  return monthDayTime.format(toDate(iso)).replace(/\//g, "月");
}

export function formatDate(iso: string): string {
  return monthDay.format(toDate(iso));
}

export function formatRelative(iso: string, now = Date.now()): string {
  const time = toDate(iso).getTime();
  const diff = now - time;

  if (Number.isNaN(time)) return "";
  if (diff < 0) return formatAbsolute(iso);
  if (diff < 60 * 1000) return "刚刚";
  if (diff < 60 * 60 * 1000) return `${Math.floor(diff / 60000)} 分钟前`;
  if (diff < 24 * 60 * 60 * 1000) return `${Math.floor(diff / 3600000)} 小时前`;
  if (diff < 48 * 60 * 60 * 1000) return "昨天";
  if (diff < 7 * 24 * 60 * 60 * 1000)
    return `${Math.floor(diff / 86400000)} 天前`;
  return formatDate(iso);
}

const stampFormat = new Intl.DateTimeFormat("zh-CN", {
  timeZone: "Asia/Shanghai",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hour12: false,
});

export function formatStamp(iso: string): string {
  const parts = stampFormat.formatToParts(toDate(iso));
  const lookup = (type: string) =>
    parts.find((part) => part.type === type)?.value ?? "00";
  return `${lookup("year")}-${lookup("month")}-${lookup("day")} ${lookup(
    "hour",
  )}:${lookup("minute")}:${lookup("second")}`;
}
