export type CategoryGroup = "activity" | "notice";

export type CategoryId =
  | "lectures"
  | "arts"
  | "clubs"
  | "careers"
  | "exchange"
  | "growth"
  | "campus"
  | "research"
  | "departments"
  | "life"
  | "academics"
  | "scholarships"
  | "services";

export interface Category {
  id: CategoryId;
  label: string;
  group: CategoryGroup;
  description: string;
  color: string;
}

export interface Notice {
  id: string;
  title: string;
  source_id: string;
  source_name: string;
  category: CategoryId;
  intent: CategoryGroup;
  published_at: string;
  url: string;
  summary?: string;
  cover_image?: string;
  requires_registration?: boolean;
  location?: string;
  event_start?: string;
}

export interface Source {
  id: string;
  name: string;
  type: "official_site" | "wechat";
  unit: string;
  homepage?: string;
  listing_url?: string;
  content_types: string[];
  categories?: CategoryId[];
  cadence?: string;
  wechat_id?: string;
  priority?: "high" | "medium" | "low";
  notes?: string;
}

export interface DataMeta {
  generated_at: string;
  notice_count: number;
  source_count: number;
}
