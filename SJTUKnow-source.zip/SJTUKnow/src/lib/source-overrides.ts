"use client";

import type { Source } from "./types";

export type ManagedSource = Source & { count: number };

export interface SourceOverrides {
  hidden: string[];
  custom: ManagedSource[];
}

const STORAGE_KEY = "sjtuknow:source-overrides";
const EMPTY: SourceOverrides = { hidden: [], custom: [] };

let cached: SourceOverrides | null = null;
const listeners = new Set<() => void>();

function read(): SourceOverrides {
  if (typeof window === "undefined") return EMPTY;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return EMPTY;
    const parsed = JSON.parse(raw) as Partial<SourceOverrides>;
    return {
      hidden: Array.isArray(parsed.hidden) ? parsed.hidden : [],
      custom: Array.isArray(parsed.custom) ? parsed.custom : [],
    };
  } catch {
    return EMPTY;
  }
}

export function getOverrides(): SourceOverrides {
  if (typeof window === "undefined") return EMPTY;
  if (cached === null) cached = read();
  return cached;
}

export function getServerOverrides(): SourceOverrides {
  return EMPTY;
}

export function subscribeOverrides(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function syncAddSource(source: ManagedSource) {
  if (typeof window === "undefined") return;
  void fetch("/api/custom-sources", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      source: {
        id: source.id,
        name: source.name,
        type: source.type,
        url: source.homepage ?? source.listing_url ?? "",
      },
    }),
  }).catch(() => {});
}

function syncRemoveSource(id: string) {
  if (typeof window === "undefined") return;
  void fetch(`/api/custom-sources?id=${encodeURIComponent(id)}`, {
    method: "DELETE",
  }).catch(() => {});
}

function persist(next: SourceOverrides) {
  cached = next;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Storage may be unavailable (private mode); keep the in-memory copy.
  }
  for (const listener of listeners) listener();
}

export function addCustomSource(input: {
  name: string;
  url: string;
  type: "official_site" | "wechat";
}): string {
  const current = getOverrides();
  const id = `custom_${Date.now().toString(36)}`;
  const source: ManagedSource = {
    id,
    name: input.name.trim(),
    unit: "自定义来源",
    type: input.type,
    homepage: input.url.trim(),
    listing_url: input.url.trim(),
    content_types: ["自定义"],
    count: 0,
    notes: "用户添加（保存在本机）",
  };
  persist({ ...current, custom: [...current.custom, source] });
  syncAddSource(source);
  return id;
}

export function removeManagedSource(id: string) {
  const current = getOverrides();
  if (id.startsWith("custom_")) {
    persist({
      ...current,
      custom: current.custom.filter((source) => source.id !== id),
    });
    syncRemoveSource(id);
    return;
  }
  if (current.hidden.includes(id)) return;
  persist({ ...current, hidden: [...current.hidden, id] });
}

export function restoreManagedSource(id: string) {
  const current = getOverrides();
  persist({
    ...current,
    hidden: current.hidden.filter((hiddenId) => hiddenId !== id),
  });
}

export function mergeSources(
  sources: ManagedSource[],
  overrides: SourceOverrides,
): ManagedSource[] {
  const merged = new Map<string, ManagedSource>();
  for (const source of sources) {
    if (overrides.hidden.includes(source.id)) continue;
    merged.set(source.id, source);
  }
  for (const custom of overrides.custom) {
    // The server list may already contain this source after a refresh; keep
    // the server copy so notice counts are preserved.
    if (!merged.has(custom.id)) merged.set(custom.id, custom);
  }
  return Array.from(merged.values());
}
