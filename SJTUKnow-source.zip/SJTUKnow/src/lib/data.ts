import noticesData from "@/data/notices.json";
import sourcesData from "@/data/sources.json";
import metaData from "@/data/meta.json";
import { CATEGORIES, CATEGORY_MAP, isVisibleCategory } from "./categories";
import type { CategoryId, DataMeta, Notice, Source } from "./types";

const notices = (noticesData as Notice[])
  .filter((notice) => isVisibleCategory(notice.category))
  .sort(
    (a, b) =>
      new Date(b.published_at).getTime() - new Date(a.published_at).getTime(),
  );

const sources = sourcesData as Source[];
const meta = metaData as DataMeta;

export function getAllNotices(): Notice[] {
  return notices;
}

export function getNotice(id: string): Notice | undefined {
  return notices.find((notice) => notice.id === id);
}

export function getNoticesByCategory(
  category: CategoryId,
  sort?: "cover",
): Notice[] {
  const results = notices.filter((notice) => notice.category === category);
  if (sort === "cover") {
    results.sort((a, b) => Number(Boolean(b.cover_image)) - Number(Boolean(a.cover_image)));
  }
  return results;
}

export function getLatestNotices(limit = 12): Notice[] {
  return notices.slice(0, limit);
}

export function searchNotices(query: string): Notice[] {
  const keyword = query.trim().toLowerCase();
  if (!keyword) return [];
  return notices.filter((notice) => {
    const haystack = `${notice.title} ${notice.source_name} ${
      notice.summary ?? ""
    }`.toLowerCase();
    return haystack.includes(keyword);
  });
}

export function getCategoriesWithCounts() {
  return CATEGORIES.filter((category) => isVisibleCategory(category.id)).map((category) => ({
    ...category,
    count: notices.filter((notice) => notice.category === category.id).length,
  })).sort((a, b) => b.count - a.count);
}

export function getSources(): Source[] {
  return sources;
}

export function getOfficialSources(): Source[] {
  return sources.filter((source) => source.type === "official_site");
}

export function getWechatSources(): Source[] {
  return sources.filter((source) => source.type === "wechat");
}

export function getSourcesWithCounts() {
  const counts = new Map<string, number>();
  for (const notice of notices) {
    counts.set(notice.source_id, (counts.get(notice.source_id) ?? 0) + 1);
  }
  return sources.map((source) => ({
    ...source,
    count: counts.get(source.id) ?? 0,
  }));
}

export function getStats() {
  const sourceCount = sources.length;
  return {
    noticeCount: notices.length,
    sourceCount,
    officialCount: sources.filter((source) => source.type === "official_site")
      .length,
    wechatCount: sources.filter((source) => source.type === "wechat").length,
    generatedAt: meta.generated_at,
    categoryCount: CATEGORIES.filter((category) =>
      notices.some((notice) => notice.category === category.id),
    ).length,
  };
}

export function getCategory(id: string) {
  return CATEGORY_MAP[id as CategoryId];
}

export function getSourceName(sourceId: string): string | undefined {
  return sources.find((source) => source.id === sourceId)?.name;
}
